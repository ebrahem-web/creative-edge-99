/* clarity-js v0.8.41: https://github.com/microsoft/clarity (License: MIT) */ ! function() {
    "use strict";
    var t = Object.freeze({
            __proto__: null,
            get add() {
                return Ja
            },
            get get() {
                return ir
            },
            get getId() {
                return Ba
            },
            get getNode() {
                return ar
            },
            get getValue() {
                return rr
            },
            get has() {
                return ur
            },
            get hashText() {
                return nr
            },
            get iframe() {
                return Za
            },
            get iframeContent() {
                return Qa
            },
            get lookup() {
                return or
            },
            get parse() {
                return Va
            },
            get removeIFrame() {
                return $a
            },
            get sameorigin() {
                return Ka
            },
            get start() {
                return qa
            },
            get stop() {
                return Ua
            },
            get update() {
                return Ga
            },
            get updates() {
                return cr
            }
        }),
        e = Object.freeze({
            __proto__: null,
            get queue() {
                return ni
            },
            get start() {
                return ei
            },
            get stop() {
                return ai
            },
            get track() {
                return Jr
            }
        }),
        n = Object.freeze({
            __proto__: null,
            get data() {
                return Ri
            },
            get start() {
                return Ai
            },
            get stop() {
                return ji
            },
            get upgrade() {
                return Yi
            }
        }),
        a = Object.freeze({
            __proto__: null,
            get check() {
                return Wi
            },
            get compute() {
                return Hi
            },
            get data() {
                return Pi
            },
            get start() {
                return Li
            },
            get stop() {
                return qi
            },
            get trigger() {
                return zi
            }
        }),
        r = Object.freeze({
            __proto__: null,
            get compute() {
                return Ki
            },
            get data() {
                return Ui
            },
            get log() {
                return Gi
            },
            get reset() {
                return Zi
            },
            get start() {
                return Bi
            },
            get stop() {
                return Ji
            },
            get updates() {
                return Fi
            }
        }),
        i = Object.freeze({
            __proto__: null,
            get callback() {
                return ho
            },
            get callbacks() {
                return $i
            },
            get clear() {
                return po
            },
            get consent() {
                return co
            },
            get consentv2() {
                return so
            },
            get data() {
                return Qi
            },
            get electron() {
                return to
            },
            get id() {
                return uo
            },
            get metadata() {
                return oo
            },
            get save() {
                return vo
            },
            get shortid() {
                return yo
            },
            get start() {
                return ro
            },
            get stop() {
                return io
            }
        }),
        o = Object.freeze({
            __proto__: null,
            get data() {
                return To
            },
            get envelope() {
                return Mo
            },
            get start() {
                return _o
            },
            get stop() {
                return No
            }
        }),
        u = {
            projectId: null,
            delay: 1e3,
            lean: !1,
            lite: !1,
            track: !0,
            content: !0,
            drop: [],
            mask: [],
            unmask: [],
            regions: [],
            cookies: [],
            fraud: !0,
            checksum: [],
            report: null,
            upload: null,
            fallback: null,
            upgrade: null,
            action: null,
            dob: null,
            delayDom: !1,
            throttleDom: !0,
            conversions: !1,
            includeSubdomains: !0
        };

    function c(t) {
        return window.Zone && "__symbol__" in window.Zone ? window.Zone.__symbol__(t) : t
    }
    var s = 0;

    function l() {
        return performance.now() + performance.timeOrigin
    }

    function d(t) {
        void 0 === t && (t = null);
        var e = 0 === s ? l() : s,
            n = t && t.timeStamp > 0 ? t.timeStamp : performance.now(),
            a = t && t.view ? t.view.performance.timeOrigin : performance.timeOrigin;
        return Math.max(Math.round(n + a - e), 0)
    }
    var f = "0.8.41";

    function p(t, e) {
        void 0 === e && (e = null);
        for (var n, a = 5381, r = a, i = 0; i < t.length; i += 2) {
            if (a = (a << 5) + a ^ t.charCodeAt(i), i + 1 < t.length) r = (r << 5) + r ^ t.charCodeAt(i + 1)
        }
        return n = Math.abs(a + 11579 * r), (e ? n % Math.pow(2, e) : n).toString(36)
    }
    var h = /\S/gi,
        v = 255,
        g = !0,
        m = null,
        y = null,
        b = null;

    function w(t, e, n, a, r) {
        if (void 0 === a && (a = !1), t) {
            if ("input" == e && ("checkbox" === r || "radio" === r)) return t;
            switch (n) {
                case 0:
                    return t;
                case 1:
                    switch (e) {
                        case "*T":
                        case "value":
                        case "placeholder":
                        case "click":
                            return function(t) {
                                var e = -1,
                                    n = 0,
                                    a = !1,
                                    r = !1,
                                    i = !1,
                                    o = null;
                                _();
                                for (var u = 0; u < t.length; u++) {
                                    var c = t.charCodeAt(u);
                                    if (a = a || c >= 48 && c <= 57, r = r || 64 === c, i = 9 === c || 10 === c || 13 === c || 32 === c, 0 === u || u === t.length - 1 || i) {
                                        if (a || r) {
                                            null === o && (o = t.split(""));
                                            var s = t.substring(e + 1, i ? u : u + 1);
                                            s = g && null !== b ? s.match(b) ? s : E(s, "▪", "▫") : O(s), o.splice(e + 1 - n, s.length, s), n += s.length - 1
                                        }
                                        i && (a = !1, r = !1, e = u)
                                    }
                                }
                                return o ? o.join("") : t
                            }(t);
                        case "input":
                        case "change":
                            return T(t)
                    }
                    return t;
                case 2:
                case 3:
                    switch (e) {
                        case "*T":
                        case "data-":
                            return a ? k(t) : O(t);
                        case "src":
                        case "srcset":
                        case "title":
                        case "alt":
                            return 3 === n ? "src" === e && (null == t ? void 0 : t.startsWith("blob:")) ? "blob:" : "" : t;
                        case "value":
                        case "click":
                        case "input":
                        case "change":
                            return T(t);
                        case "placeholder":
                            return O(t)
                    }
                    break;
                case 4:
                    switch (e) {
                        case "*T":
                        case "data-":
                            return a ? k(t) : O(t);
                        case "value":
                        case "input":
                        case "click":
                        case "change":
                            return Array(5).join("•");
                        case "checksum":
                            return ""
                    }
                    break;
                case 5:
                    switch (e) {
                        case "*T":
                        case "data-":
                            return E(t, "▪", "▫");
                        case "value":
                        case "input":
                        case "click":
                        case "change":
                            return Array(5).join("•");
                        case "checksum":
                        case "src":
                        case "srcset":
                        case "alt":
                        case "title":
                            return ""
                    }
            }
        }
        return t
    }

    function S(t, e, n) {
        void 0 === e && (e = !1), void 0 === n && (n = !1);
        var a = t;
        if (e) a = "".concat("https://").concat("Electron");
        else {
            var r = u.drop;
            if (r && r.length > 0 && t && t.indexOf("?") > 0) {
                var i = t.split("?"),
                    o = i[0],
                    c = i[1];
                a = o + "?" + c.split("&").map((function(t) {
                    return r.some((function(e) {
                        return 0 === t.indexOf("".concat(e, "="))
                    })) ? "".concat(t.split("=")[0], "=").concat("*na*") : t
                })).join("&")
            }
        }
        return n && (a = a.substring(0, v)), a
    }

    function k(t) {
        var e = t.trim();
        if (e.length > 0) {
            var n = e[0],
                a = t.indexOf(n),
                r = t.substr(0, a),
                i = t.substr(a + e.length);
            return "".concat(r).concat(e.length.toString(36)).concat(i)
        }
        return t
    }

    function O(t) {
        return t.replace(h, "•")
    }

    function E(t, e, n) {
        return _(), t ? t.replace(y, e).replace(m, n) : t
    }

    function T(t) {
        for (var e = 5 * (Math.floor(t.length / 5) + 1), n = "", a = 0; a < e; a++) n += a > 0 && a % 5 == 0 ? " " : "•";
        return n
    }

    function _() {
        if (g && null === m) try {
            m = new RegExp("\\p{N}", "gu"), y = new RegExp("\\p{L}", "gu"), b = new RegExp("\\p{Sc}", "gu")
        } catch (t) {
            g = !1
        }
    }
    var N = null,
        M = null,
        x = !1;

    function I() {
        x && (N = {
            time: d(),
            event: 4,
            data: {
                visible: M.visible,
                docWidth: M.docWidth,
                docHeight: M.docHeight,
                screenWidth: M.screenWidth,
                screenHeight: M.screenHeight,
                scrollX: M.scrollX,
                scrollY: M.scrollY,
                pointerX: M.pointerX,
                pointerY: M.pointerY,
                activityTime: M.activityTime,
                scrollTime: M.scrollTime,
                pointerTime: M.pointerTime,
                moveX: M.moveX,
                moveY: M.moveY,
                moveTime: M.moveTime,
                downX: M.downX,
                downY: M.downY,
                downTime: M.downTime,
                upX: M.upX,
                upY: M.upY,
                upTime: M.upTime,
                pointerPrevX: M.pointerPrevX,
                pointerPrevY: M.pointerPrevY,
                pointerPrevTime: M.pointerPrevTime,
                modules: M.modules
            }
        }), M = M || {
            visible: 1,
            docWidth: 0,
            docHeight: 0,
            screenWidth: 0,
            screenHeight: 0,
            scrollX: 0,
            scrollY: 0,
            pointerX: 0,
            pointerY: 0,
            activityTime: 0,
            scrollTime: 0,
            pointerTime: void 0,
            moveX: void 0,
            moveY: void 0,
            moveTime: void 0,
            downX: void 0,
            downY: void 0,
            downTime: void 0,
            upX: void 0,
            upY: void 0,
            upTime: void 0,
            pointerPrevX: void 0,
            pointerPrevY: void 0,
            pointerPrevTime: void 0,
            modules: null
        }
    }

    function C(t, e, n, a) {
        switch (t) {
            case 8:
                M.docWidth = e, M.docHeight = n;
                break;
            case 11:
                M.screenWidth = e, M.screenHeight = n;
                break;
            case 10:
                M.scrollX = e, M.scrollY = n, M.scrollTime = a;
                break;
            case 12:
                M.moveX = e, M.moveY = n, M.moveTime = a, M.pointerPrevX = M.pointerX, M.pointerPrevY = M.pointerY, M.pointerPrevTime = M.pointerTime, M.pointerX = e, M.pointerY = n, M.pointerTime = a;
                break;
            case 13:
                M.downX = e, M.downY = n, M.downTime = a, M.pointerPrevX = M.pointerX, M.pointerPrevY = M.pointerY, M.pointerPrevTime = M.pointerTime, M.pointerX = e, M.pointerY = n, M.pointerTime = a;
                break;
            case 14:
                M.upX = e, M.upY = n, M.upTime = a, M.pointerPrevX = M.pointerX, M.pointerPrevY = M.pointerY, M.pointerPrevTime = M.pointerTime, M.pointerX = e, M.pointerY = n, M.pointerTime = a;
                break;
            default:
                M.pointerPrevX = M.pointerX, M.pointerPrevY = M.pointerY, M.pointerPrevTime = M.pointerTime, M.pointerX = e, M.pointerY = n, M.pointerTime = a
        }
        x = !0
    }

    function D(t) {
        M.activityTime = t
    }

    function P(t, e) {
        M.visible = e, M.visible || D(t), x = !0
    }

    function R(t) {
        M.modules = Array.from(t), x = !0
    }

    function A() {
        x && Xi(4)
    }
    var Y = Object.freeze({
            __proto__: null,
            activity: D,
            compute: A,
            dynamic: R,
            reset: I,
            start: function() {
                x = !1, I()
            },
            get state() {
                return N
            },
            stop: function() {
                I()
            },
            track: C,
            visibility: P
        }),
        j = null,
        X = !0;

    function L() {
        var t, e = null === (t = window.google_tag_data) || void 0 === t ? void 0 : t.ics;
        if (null == e ? void 0 : e.getConsentState) {
            var n = e.getConsentState("analytics_storage");
            so(function(t) {
                var e = {
                    ad_Storage: 1 === t.ad_Storage ? "granted" : "denied",
                    analytics_Storage: 1 === t.analytics_Storage ? "granted" : "denied"
                };
                return e
            }({
                ad_Storage: e.getConsentState("ad_storage"),
                analytics_Storage: n
            }), 2)
        }
    }

    function W(t) {
        H(t.analytics_Storage ? 1 : 0), j = t
    }

    function z() {
        H(2)
    }

    function H(t) {
        Gi(36, t.toString())
    }

    function q(t) {
        j = t, Xi(47)
    }

    function U() {
        var t;
        if (X && (Xi(47), X = !1, !u.track)) {
            var e = null === (t = window.google_tag_data) || void 0 === t ? void 0 : t.ics;
            (null == e ? void 0 : e.usedUpdate) && L()
        }
    }
    var F = Object.freeze({
            __proto__: null,
            compute: U,
            config: W,
            consent: z,
            get data() {
                return j
            },
            start: function() {
                var t, e = null === (t = window.google_tag_data) || void 0 === t ? void 0 : t.ics;
                X = !0, (null == e ? void 0 : e.addListener) && e.addListener(["ad_storage", "analytics_storage"], L)
            },
            stop: function() {
                X = !0
            },
            trackConsentv2: q
        }),
        V = null;

    function B(t, e) {
        Go() && t && "string" == typeof t && t.length < 255 && (V = e && "string" == typeof e && e.length < 255 ? {
            key: t,
            value: e
        } : {
            value: t
        }, Xi(24))
    }
    var J, G = null,
        K = null;

    function Z(t) {
        t in G || (G[t] = 0), t in K || (K[t] = 0), G[t]++, K[t]++
    }

    function Q(t, e) {
        null !== e && (t in G || (G[t] = 0), t in K || (K[t] = 0), G[t] += e, K[t] += e)
    }

    function $(t, e) {
        null !== e && !1 === isNaN(e) && (t in G || (G[t] = 0), (e > G[t] || 0 === G[t]) && (K[t] = e, G[t] = e))
    }

    function tt(t, e, n) {
        return window.setTimeout(Co(t), e, n)
    }

    function et(t) {
        return window.clearTimeout(t)
    }
    var nt = 0,
        at = 0,
        rt = null;

    function it() {
        rt && et(rt), rt = tt(ot, at), nt = d()
    }

    function ot() {
        var t = d();
        J = {
            gap: t - nt
        }, Xi(25), J.gap < 3e5 ? rt = tt(ot, at) : Vo && (B("clarity", "suspend"), wu(), ["mousemove", "touchstart"].forEach((function(t) {
            return Po(document, t, Ko)
        })), ["resize", "scroll", "pageshow"].forEach((function(t) {
            return Po(window, t, Ko)
        })))
    }
    var ut = Object.freeze({
            __proto__: null,
            get data() {
                return J
            },
            reset: it,
            start: function() {
                at = 6e4, nt = 0
            },
            stop: function() {
                et(rt), nt = 0, at = 0
            }
        }),
        ct = null;

    function st(t, e) {
        if (t in ct) {
            var n = ct[t],
                a = n[n.length - 1];
            e - a[0] > 100 ? ct[t].push([e, 0]) : a[1] = e - a[0]
        } else ct[t] = [
            [e, 0]
        ]
    }

    function lt() {
        Xi(36)
    }

    function dt() {
        ct = {}
    }
    var ft = Object.freeze({
        __proto__: null,
        compute: lt,
        get data() {
            return ct
        },
        reset: dt,
        start: function() {
            ct = {}
        },
        stop: function() {
            ct = {}
        },
        track: st
    });

    function pt(t, e, n, a) {
        return new(n || (n = Promise))((function(r, i) {
            function o(t) {
                try {
                    c(a.next(t))
                } catch (t) {
                    i(t)
                }
            }

            function u(t) {
                try {
                    c(a.throw(t))
                } catch (t) {
                    i(t)
                }
            }

            function c(t) {
                var e;
                t.done ? r(t.value) : (e = t.value, e instanceof n ? e : new n((function(t) {
                    t(e)
                }))).then(o, u)
            }
            c((a = a.apply(t, e || [])).next())
        }))
    }

    function ht(t, e) {
        var n, a, r, i, o = {
            label: 0,
            sent: function() {
                if (1 & r[0]) throw r[1];
                return r[1]
            },
            trys: [],
            ops: []
        };
        return i = {
            next: u(0),
            throw: u(1),
            return: u(2)
        }, "function" == typeof Symbol && (i[Symbol.iterator] = function() {
            return this
        }), i;

        function u(u) {
            return function(c) {
                return function(u) {
                    if (n) throw new TypeError("Generator is already executing.");
                    for (; i && (i = 0, u[0] && (o = 0)), o;) try {
                        if (n = 1, a && (r = 2 & u[0] ? a.return : u[0] ? a.throw || ((r = a.return) && r.call(a), 0) : a.next) && !(r = r.call(a, u[1])).done) return r;
                        switch (a = 0, r && (u = [2 & u[0], r.value]), u[0]) {
                            case 0:
                            case 1:
                                r = u;
                                break;
                            case 4:
                                return o.label++, {
                                    value: u[1],
                                    done: !1
                                };
                            case 5:
                                o.label++, a = u[1], u = [0];
                                continue;
                            case 7:
                                u = o.ops.pop(), o.trys.pop();
                                continue;
                            default:
                                if (!(r = o.trys, (r = r.length > 0 && r[r.length - 1]) || 6 !== u[0] && 2 !== u[0])) {
                                    o = 0;
                                    continue
                                }
                                if (3 === u[0] && (!r || u[1] > r[0] && u[1] < r[3])) {
                                    o.label = u[1];
                                    break
                                }
                                if (6 === u[0] && o.label < r[1]) {
                                    o.label = r[1], r = u;
                                    break
                                }
                                if (r && o.label < r[2]) {
                                    o.label = r[2], o.ops.push(u);
                                    break
                                }
                                r[2] && o.ops.pop(), o.trys.pop();
                                continue
                        }
                        u = e.call(t, o)
                    } catch (t) {
                        u = [6, t], a = 0
                    } finally {
                        n = r = 0
                    }
                    if (5 & u[0]) throw u[1];
                    return {
                        value: u[0] ? u[1] : void 0,
                        done: !0
                    }
                }([u, c])
            }
        }
    }
    var vt = "CompressionStream" in window;

    function gt(t) {
        return pt(this, void 0, void 0, (function() {
            var e, n;
            return ht(this, (function(a) {
                switch (a.label) {
                    case 0:
                        return a.trys.push([0, 3, , 4]), vt ? (e = new ReadableStream({
                            start: function(e) {
                                return pt(this, void 0, void 0, (function() {
                                    return ht(this, (function(n) {
                                        return e.enqueue(t), e.close(), [2]
                                    }))
                                }))
                            }
                        }).pipeThrough(new TextEncoderStream).pipeThrough(new window.CompressionStream("gzip")), n = Uint8Array.bind, [4, mt(e)]) : [3, 2];
                    case 1:
                        return [2, new(n.apply(Uint8Array, [void 0, a.sent()]))];
                    case 2:
                        return [3, 4];
                    case 3:
                        return a.sent(), [3, 4];
                    case 4:
                        return [2, null]
                }
            }))
        }))
    }

    function mt(t) {
        return pt(this, void 0, void 0, (function() {
            var e, n, a, r, i;
            return ht(this, (function(o) {
                switch (o.label) {
                    case 0:
                        e = t.getReader(), n = [], a = !1, r = [], o.label = 1;
                    case 1:
                        return a ? [3, 3] : [4, e.read()];
                    case 2:
                        return i = o.sent(), a = i.done, r = i.value, a ? [2, n] : (n.push.apply(n, r), [3, 1]);
                    case 3:
                        return [2, n]
                }
            }))
        }))
    }
    var yt = null;

    function bt(t, e) {
        St(t, "string" == typeof e ? [e] : e)
    }

    function wt(t, e, n, a) {
        return void 0 === e && (e = null), void 0 === n && (n = null), void 0 === a && (a = null), pt(this, void 0, void 0, (function() {
            var r, i;
            return ht(this, (function(o) {
                switch (o.label) {
                    case 0:
                        return i = {}, [4, Et(t)];
                    case 1:
                        return i.userId = o.sent(), i.userHint = a || ((u = t) && u.length >= 5 ? "".concat(u.substring(0, 2)).concat(E(u.substring(2), "*", "*")) : E(u, "*", "*")), St("userId", [(r = i).userId]), St("userHint", [r.userHint]), St("userType", [Tt(t)]), e && (St("sessionId", [e]), r.sessionId = e), n && (St("pageId", [n]), r.pageId = n), [2, r]
                }
                var u
            }))
        }))
    }

    function St(t, e) {
        if (Go() && t && e && "string" == typeof t && t.length < 255) {
            for (var n = (t in yt ? yt[t] : []), a = 0; a < e.length; a++) "string" == typeof e[a] && e[a].length < 255 && n.push(e[a]);
            yt[t] = n
        }
    }

    function kt() {
        Xi(34)
    }

    function Ot() {
        yt = {}
    }

    function Et(t) {
        return pt(this, void 0, void 0, (function() {
            var e;
            return ht(this, (function(n) {
                switch (n.label) {
                    case 0:
                        return n.trys.push([0, 4, , 5]), crypto && t ? [4, crypto.subtle.digest("SHA-256", (new TextEncoder).encode(t))] : [3, 2];
                    case 1:
                        return e = n.sent(), [2, Array.prototype.map.call(new Uint8Array(e), (function(t) {
                            return ("00" + t.toString(16)).slice(-2)
                        })).join("")];
                    case 2:
                        return [2, ""];
                    case 3:
                        return [3, 5];
                    case 4:
                        return n.sent(), [2, ""];
                    case 5:
                        return [2]
                }
            }))
        }))
    }

    function Tt(t) {
        return t && t.indexOf("@") > 0 ? "email" : "string"
    }
    var _t = Object.freeze({
            __proto__: null,
            compute: kt,
            get data() {
                return yt
            },
            identify: wt,
            reset: Ot,
            set: bt,
            start: function() {
                Ot()
            },
            stop: function() {
                Ot()
            }
        }),
        Nt = {},
        Mt = new Set,
        xt = {},
        It = {},
        Ct = {},
        Dt = {};

    function Pt(t) {
        try {
            var e = t && t.length > 0 ? t.split(/ (.*)/) : [""],
                n = e[0].split(/\|(.*)/),
                a = parseInt(n[0]),
                r = n.length > 1 ? n[1] : "",
                i = e.length > 1 ? JSON.parse(e[1]) : {};
            for (var o in xt[a] = {}, It[a] = {}, Ct[a] = {}, Dt[a] = r, i) {
                var u = parseInt(o),
                    c = i[o],
                    s = 2;
                switch (c.startsWith("~") ? s = 0 : c.startsWith("!") && (s = 4), s) {
                    case 0:
                        var l = c.slice(1);
                        xt[a][u] = Xt(l);
                        break;
                    case 2:
                        It[a][u] = c;
                        break;
                    case 4:
                        var d = c.slice(1);
                        Ct[a][u] = d
                }
            }
        } catch (t) {
            hi(8, 1, t ? t.name : null)
        }
    }

    function Rt(t) {
        return JSON.parse(JSON.stringify(t))
    }

    function At() {
        try {
            for (var t in xt) {
                var e = parseInt(t);
                if ("" == Dt[e] || document.querySelector(Dt[e])) {
                    var n = xt[e];
                    for (var a in n) {
                        var r = parseInt(a),
                            i = (m = Lt(Rt(n[r]))) ? JSON.stringify(m).slice(0, 1e4) : m;
                        i && jt(e, r, i)
                    }
                    var o = It[e];
                    for (var u in o) {
                        var c = !1,
                            s = parseInt(u),
                            l = o[s];
                        l.startsWith("@") && (c = !0, l = l.slice(1));
                        var d = document.querySelectorAll(l);
                        if (d) {
                            var f = Array.from(d).map((function(t) {
                                return t.textContent
                            })).join("<SEP>");
                            jt(e, s, (c ? p(f).trim() : f).slice(0, 1e4))
                        }
                    }
                    var h = Ct[e];
                    for (var v in h) {
                        var g = parseInt(v);
                        jt(e, g, nr(h[g]).trim().slice(0, 1e4))
                    }
                }
            }
            Mt.size > 0 && Xi(40)
        } catch (t) {
            hi(5, 1, t ? t.name : null)
        }
        var m
    }

    function Yt() {
        Mt.clear()
    }

    function jt(t, e, n) {
        var a, r = !1;
        t in Nt || (Nt[t] = {}, r = !0), a = Ct[t], 0 == Object.keys(a).length || e in Nt[t] && Nt[t][e] == n || (r = !0), Nt[t][e] = n, r && Mt.add(t)
    }

    function Xt(t) {
        for (var e = [], n = t.split("."); n.length > 0;) {
            var a = n.shift(),
                r = a.indexOf("["),
                i = a.indexOf("{"),
                o = a.indexOf("}");
            e.push({
                name: r > 0 ? a.slice(0, r) : i > 0 ? a.slice(0, i) : a,
                type: r > 0 ? 1 : i > 0 ? 2 : 3,
                condition: i > 0 ? a.slice(i + 1, o) : null
            })
        }
        return e
    }

    function Lt(t, e) {
        if (void 0 === e && (e = window), 0 == t.length) return e;
        var n, a = t.shift();
        if (e && e[a.name]) {
            var r = e[a.name];
            if (1 !== a.type && Wt(r, a.condition)) n = Lt(t, r);
            else if (Array.isArray(r)) {
                for (var i = [], o = 0, u = r; o < u.length; o++) {
                    var c = u[o];
                    if (Wt(c, a.condition)) {
                        var s = Lt(t, c);
                        s && i.push(s)
                    }
                }
                n = i
            }
            return n
        }
        return null
    }

    function Wt(t, e) {
        if (e) {
            var n = e.split(":");
            return n.length > 1 ? t[n[0]] == n[1] : t[n[0]]
        }
        return !0
    }
    var zt = null;

    function Ht(t) {
        try {
            if (!zt) return;
            var e = function(t) {
                try {
                    return JSON.parse(t)
                } catch (t) {
                    return []
                }
            }(t);
            e.forEach((function(t) {
                zt(t)
            }))
        } catch (t) {}
    }
    var qt = [Y, r, _t, a, ft, F, i, o, e, ut, n, Object.freeze({
        __proto__: null,
        clone: Rt,
        compute: At,
        data: Nt,
        keys: Mt,
        reset: Yt,
        start: function() {
            Yt()
        },
        stop: function() {
            Yt()
        },
        trigger: Pt,
        update: jt
    })];

    function Ut() {
        G = {}, K = {}, Z(5), qt.forEach((function(t) {
            return Co(t.start)()
        }))
    }

    function Ft() {
        qt.slice().reverse().forEach((function(t) {
            return Co(t.stop)()
        })), G = {}, K = {}
    }

    function Vt() {
        kt(), A(), Ki(), Xi(0), lt(), Hi(), At(), U()
    }
    var Bt, Jt = [];

    function Gt(t, e, n) {
        u.fraud && null !== t && n && n.length >= 5 && (Bt = {
            id: t,
            target: e,
            checksum: p(n, 28)
        }, Jt.indexOf(Bt.checksum) < 0 && (Jt.push(Bt.checksum), di(41)))
    }
    var Kt = [];

    function Zt(t) {
        var e = Tr(t);
        if (e) {
            var n = e.value,
                a = n && n.length >= 5 && u.fraud && -1 === "password,secret,pass,social,ssn,code,hidden".indexOf(e.type) ? p(n, 28) : "";
            Kt.push({
                time: d(t),
                event: 42,
                data: {
                    target: Tr(t),
                    type: e.type,
                    value: n,
                    checksum: a
                }
            }), ki(Nr.bind(this, 42))
        }
    }

    function Qt() {
        Kt = []
    }

    function $t(t) {
        var e = {
            x: 0,
            y: 0
        };
        if (t && t.offsetParent)
            do {
                var n = t.offsetParent,
                    a = null === n ? Za(t.ownerDocument) : null;
                e.x += t.offsetLeft, e.y += t.offsetTop, t = a || n
            } while (t);
        return e
    }
    var te = ["input", "textarea", "radio", "button", "canvas", "select"],
        ee = [];

    function ne(t, e, n) {
        var a = Za(e),
            r = a && a.contentDocument ? a.contentDocument.documentElement : document.documentElement,
            i = "pageX" in n ? Math.round(n.pageX) : "clientX" in n ? Math.round(n.clientX + r.scrollLeft) : null,
            o = "pageY" in n ? Math.round(n.pageY) : "clientY" in n ? Math.round(n.clientY + r.scrollTop) : null;
        if (a) {
            var u = $t(a);
            i = i ? i + Math.round(u.x) : i, o = o ? o + Math.round(u.y) : o
        }
        var c = Tr(n),
            s = function(t) {
                for (; t && t !== document;) {
                    if (t.nodeType === Node.ELEMENT_NODE) {
                        var e = t;
                        if ("A" === e.tagName) return e
                    }
                    t = t.parentNode
                }
                return null
            }(c),
            l = function(t) {
                var e = null,
                    n = document.documentElement;
                if ("function" == typeof t.getBoundingClientRect) {
                    var a = t.getBoundingClientRect();
                    a && a.width > 0 && a.height > 0 && (e = {
                        x: Math.floor(a.left + ("pageXOffset" in window ? window.pageXOffset : n.scrollLeft)),
                        y: Math.floor(a.top + ("pageYOffset" in window ? window.pageYOffset : n.scrollTop)),
                        w: Math.floor(a.width),
                        h: Math.floor(a.height)
                    })
                }
                return e
            }(c);
        0 === n.detail && l && (i = Math.round(l.x + l.w / 2), o = Math.round(l.y + l.h / 2));
        var f = l ? Math.max(Math.floor((i - l.x) / l.w * 32767), 0) : 0,
            p = l ? Math.max(Math.floor((o - l.y) / l.h * 32767), 0) : 0;
        if (null !== i && null !== o) {
            var h = function(t) {
                var e = null,
                    n = !1;
                if (t) {
                    var a = t.textContent || String(t.value || "") || t.alt;
                    if (a) {
                        var r = a.replace(/\s+/g, " ").trim();
                        n = (e = r.substring(0, 25)).length === r.length
                    }
                }
                return {
                    text: e,
                    isFullText: n ? 1 : 0
                }
            }(c);
            ee.push({
                time: d(n),
                event: t,
                data: {
                    target: c,
                    x: i,
                    y: o,
                    eX: f,
                    eY: p,
                    button: n.button,
                    reaction: ae(c),
                    context: ie(s),
                    text: h.text,
                    link: s ? s.href : null,
                    hash: null,
                    trust: n.isTrusted ? 1 : 0,
                    isFullText: h.isFullText,
                    w: l ? l.w : 0,
                    h: l ? l.h : 0,
                    tag: re(c, "tagName").substring(0, 10),
                    class: re(c, "className").substring(0, 50),
                    id: re(c, "id").substring(0, 25)
                }
            }), ki(Nr.bind(this, t))
        }
    }

    function ae(t) {
        var e = re(t, "tagName");
        return te.indexOf(e) >= 0 ? 0 : 1
    }

    function re(t, e) {
        if (t.nodeType === Node.ELEMENT_NODE) {
            var n = null == t ? void 0 : t[e];
            return "string" == typeof n ? null == n ? void 0 : n.toLowerCase() : ""
        }
        return ""
    }

    function ie(t) {
        if (t && t.hasAttribute("target")) switch (t.getAttribute("target")) {
            case "_blank":
                return 1;
            case "_parent":
                return 2;
            case "_top":
                return 3
        }
        return 0
    }

    function oe() {
        ee = []
    }
    var ue = [];

    function ce(t, e) {
        ue.push({
            time: d(e),
            event: 38,
            data: {
                target: Tr(e),
                action: t
            }
        }), ki(Nr.bind(this, 38))
    }

    function se() {
        ue = []
    }
    var le = null,
        de = [];

    function fe(t) {
        var e = Tr(t),
            n = ir(e);
        if (e && e.type && n) {
            var a = e.value,
                r = e.type;
            switch (e.type) {
                case "radio":
                case "checkbox":
                    a = e.checked ? "true" : "false"
            }
            var i = {
                target: e,
                value: a,
                type: r,
                trust: t.isTrusted ? 1 : 0
            };
            de.length > 0 && de[de.length - 1].data.target === i.target && de.pop(), de.push({
                time: d(t),
                event: 27,
                data: i
            }), et(le), le = tt(pe, 1e3, 27)
        }
    }

    function pe(t) {
        ki(Nr.bind(this, t))
    }

    function he() {
        de = []
    }
    var ve, ge = [],
        me = null,
        ye = !1,
        be = 0,
        we = new Set;

    function Se(t, e, n) {
        var a = Za(e),
            r = a && a.contentDocument ? a.contentDocument.documentElement : document.documentElement,
            i = "pageX" in n ? Math.round(n.pageX) : "clientX" in n ? Math.round(n.clientX + r.scrollLeft) : null,
            o = "pageY" in n ? Math.round(n.pageY) : "clientY" in n ? Math.round(n.clientY + r.scrollTop) : null;
        if (a) {
            var u = $t(a);
            i = i ? i + Math.round(u.x) : i, o = o ? o + Math.round(u.y) : o
        }
        null !== i && null !== o && Oe({
            time: d(n),
            event: t,
            data: {
                target: Tr(n),
                x: i,
                y: o
            }
        })
    }

    function ke(t, e, n) {
        var a = Za(e),
            r = a && a.contentDocument ? a.contentDocument.documentElement : document.documentElement,
            i = n.changedTouches,
            o = d(n);
        if (i)
            for (var u = 0; u < i.length; u++) {
                var c = i[u],
                    s = "clientX" in c ? Math.round(c.clientX + r.scrollLeft) : null,
                    l = "clientY" in c ? Math.round(c.clientY + r.scrollTop) : null;
                s = s && a ? s + Math.round(a.offsetLeft) : s, l = l && a ? l + Math.round(a.offsetTop) : l;
                var f = "identifier" in c ? c.identifier : void 0;
                switch (t) {
                    case 17:
                        0 === we.size && (ye = !0, be = f), we.add(f);
                        break;
                    case 18:
                    case 20:
                        we.delete(f)
                }
                var p = ye && be === f;
                null !== s && null !== l && Oe({
                    time: o,
                    event: t,
                    data: {
                        target: Tr(n),
                        x: s,
                        y: l,
                        id: f,
                        isPrimary: p
                    }
                }), 20 !== t && 18 !== t || be === f && (ye = !1)
            }
    }

    function Oe(t) {
        switch (t.event) {
            case 12:
            case 15:
            case 19:
                var e = ge.length,
                    n = e > 1 ? ge[e - 2] : null;
                n && function(t, e) {
                    var n = t.data.x - e.data.x,
                        a = t.data.y - e.data.y,
                        r = Math.sqrt(n * n + a * a),
                        i = e.time - t.time,
                        o = e.data.target === t.data.target,
                        u = void 0 === e.data.id || e.data.id === t.data.id;
                    return e.event === t.event && o && r < 20 && i < 25 && u
                }(n, t) && ge.pop(), ge.push(t), et(me), me = tt(Ee, 500, t.event);
                break;
            default:
                ge.push(t), Ee(t.event)
        }
    }

    function Ee(t) {
        ki(Nr.bind(this, t))
    }

    function Te() {
        ge = []
    }

    function _e(t, e) {
        var n = 0,
            a = null,
            r = null;

        function i() {
            for (var i = this, o = [], u = 0; u < arguments.length; u++) o[u] = arguments[u];
            var c = performance.now(),
                s = c - n;
            if (0 !== n && s < e) {
                if (r = o, a) return;
                a = setTimeout((function() {
                    n = performance.now(), t.apply(i, r), r = null, a = null
                }), e - s)
            } else n = c, t.apply(this, o)
        }
        return i.cleanup = function() {
            a && (clearTimeout(a), a = null, r = null)
        }, i
    }
    var Ne = null,
        Me = !1,
        xe = _e(Ie, 500);

    function Ie() {
        var t = document.documentElement;
        ve = {
            width: t && "clientWidth" in t ? Math.min(t.clientWidth, window.innerWidth) : window.innerWidth,
            height: t && "clientHeight" in t ? Math.min(t.clientHeight, window.innerHeight) : window.innerHeight
        }, Me ? (et(Ne), Ne = tt(Ce, 500, 11)) : (Nr(11), Me = !0)
    }

    function Ce(t) {
        ki(Nr.bind(this, t))
    }

    function De() {
        ve = null, et(Ne), xe.cleanup()
    }
    var Pe = [],
        Re = null,
        Ae = null,
        Ye = null;

    function je(t) {
        void 0 === t && (t = null);
        var e = window,
            n = document.documentElement,
            a = t ? Tr(t) : n;
        if (a) {
            if (a && a.nodeType === Node.DOCUMENT_NODE) {
                var r = Za(a);
                e = r ? r.contentWindow : e, a = n = a.documentElement
            }
            var i = a === n && "pageXOffset" in e ? Math.round(e.pageXOffset) : Math.round(a.scrollLeft),
                o = a === n && "pageYOffset" in e ? Math.round(e.pageYOffset) : Math.round(a.scrollTop),
                u = window.innerWidth,
                c = window.innerHeight,
                s = u / 3,
                l = u > c ? .15 * c : .2 * c,
                f = c - l,
                p = Le(s, l),
                h = Le(s, f),
                v = {
                    time: d(t),
                    event: 10,
                    data: {
                        target: a,
                        x: i,
                        y: o,
                        top: p,
                        bottom: h
                    }
                };
            if (null === t && 0 === i && 0 === o || null === i || null === o) return Re = p, void(Ae = h);
            var g = Pe.length,
                m = g > 1 ? Pe[g - 2] : null;
            m && function(t, e) {
                var n = t.data.x - e.data.x,
                    a = t.data.y - e.data.y;
                return n * n + a * a < 400 && e.time - t.time < 50
            }(m, v) && Pe.pop(), Pe.push(v), et(Ye), Ye = tt(We, 500, 10)
        }
    }
    var Xe = _e(je, 25);

    function Le(t, e) {
        var n, a, r;
        return "caretPositionFromPoint" in document ? r = null === (n = document.caretPositionFromPoint(t, e)) || void 0 === n ? void 0 : n.offsetNode : "caretRangeFromPoint" in document && (r = null === (a = document.caretRangeFromPoint(t, e)) || void 0 === a ? void 0 : a.startContainer), r || (r = document.elementFromPoint(t, e)), r && r.nodeType === Node.TEXT_NODE && (r = r.parentNode), r
    }

    function We(t) {
        ki(Nr.bind(this, t))
    }

    function ze() {
        var t, e;
        if (Re) {
            var n = _r(Re, null);
            Gi(31, null === (t = null == n ? void 0 : n.hash) || void 0 === t ? void 0 : t.join("."))
        }
        if (Ae) {
            var a = _r(Ae, null);
            Gi(32, null === (e = null == a ? void 0 : a.hash) || void 0 === e ? void 0 : e.join("."))
        }
    }
    var He = null,
        qe = null,
        Ue = null;

    function Fe(t) {
        var e = (t.nodeType === Node.DOCUMENT_NODE ? t : document).getSelection();
        if (null !== e && !(null === e.anchorNode && null === e.focusNode || e.anchorNode === e.focusNode && e.anchorOffset === e.focusOffset)) {
            var n = He.start ? He.start : null;
            null !== qe && null !== He.start && n !== e.anchorNode && (et(Ue), Ve(21)), He = {
                start: e.anchorNode,
                startOffset: e.anchorOffset,
                end: e.focusNode,
                endOffset: e.focusOffset
            }, qe = e, et(Ue), Ue = tt(Ve, 500, 21)
        }
    }

    function Ve(t) {
        ki(Nr.bind(this, t))
    }

    function Be() {
        qe = null, He = {
            start: 0,
            startOffset: 0,
            end: 0,
            endOffset: 0
        }
    }
    var Je, Ge, Ke, Ze = [];

    function Qe(t) {
        Ze.push({
            time: d(t),
            event: 39,
            data: {
                target: Tr(t)
            }
        }), ki(Nr.bind(this, 39))
    }

    function $e() {
        Ze = []
    }

    function tn(t) {
        Je = {
            name: t.type,
            persisted: t.persisted ? 1 : 0
        }, Nr(26, d(t)), wu()
    }

    function en() {
        Je = null
    }

    function nn(t) {
        if (void 0 === t && (t = null), "visibilityState" in document) {
            var e = "visible" === document.visibilityState ? 1 : 0;
            Ge = {
                visible: e
            }, Nr(28, d(t))
        }
    }

    function an() {
        Ge = null
    }

    function rn() {
        Ke = null
    }

    function on(t) {
        Ke = {
            focused: t
        }, Nr(50)
    }

    function un(t) {
        ! function(t) {
            var e = Za(t);
            Po(e ? e.contentWindow : t === document ? window : t, "scroll", Xe, !0)
        }(t), t.nodeType === Node.DOCUMENT_NODE && (function(t) {
            Po(t, "click", ne.bind(this, 9, t), !0), Po(t, "contextmenu", ne.bind(this, 48, t), !0)
        }(t), function(t) {
            Po(t, "cut", ce.bind(this, 0), !0), Po(t, "copy", ce.bind(this, 1), !0), Po(t, "paste", ce.bind(this, 2), !0)
        }(t), function(t) {
            Po(t, "mousedown", Se.bind(this, 13, t), !0), Po(t, "mouseup", Se.bind(this, 14, t), !0), Po(t, "mousemove", Se.bind(this, 12, t), !0), Po(t, "wheel", Se.bind(this, 15, t), !0), Po(t, "dblclick", Se.bind(this, 16, t), !0), Po(t, "touchstart", ke.bind(this, 17, t), !0), Po(t, "touchend", ke.bind(this, 18, t), !0), Po(t, "touchmove", ke.bind(this, 19, t), !0), Po(t, "touchcancel", ke.bind(this, 20, t), !0)
        }(t), function(t) {
            Po(t, "input", fe, !0)
        }(t), function(t) {
            Po(t, "selectstart", Fe.bind(this, t), !0), Po(t, "selectionchange", Fe.bind(this, t), !0)
        }(t), function(t) {
            Po(t, "change", Zt, !0)
        }(t), function(t) {
            Po(t, "submit", Qe, !0)
        }(t))
    }
    var cn = Object.freeze({
        __proto__: null,
        observe: un,
        start: function() {
            Mr = [], Ir(), oe(), se(), Te(), he(), Me = !1, Po(window, "resize", xe), Ie(), Po(document, "visibilitychange", nn), nn(), Po(window, "focus", (function() {
                return on(1)
            })), Po(window, "blur", (function() {
                return on(0)
            })), Pe = [], je(), Be(), Qt(), $e(), Po(window, "pagehide", tn)
        },
        stop: function() {
            Mr = [], Ir(), oe(), se(), et(me), ge.length > 0 && Ee(ge[ge.length - 1].event), et(le), he(), De(), an(), rn(), et(Ye), Xe.cleanup(), Pe = [], Re = null, Ae = null, Be(), et(Ue), Qt(), $e(), en()
        }
    });

    function sn(t) {
        for (var e = [], n = {}, a = 0, r = null, i = 0; i < t.length; i++)
            if ("string" == typeof t[i]) {
                var o = t[i],
                    u = n[o] || -1;
                u >= 0 ? r ? r.push(u) : (r = [u], e.push(r), a++) : (r = null, e.push(o), n[o] = a++)
            } else r = null, e.push(t[i]), a++;
        return e
    }
    var ln = [],
        dn = [],
        fn = "claritySheetId",
        pn = {},
        hn = {},
        vn = [],
        gn = [];

    function mn(t) {
        u.lean && u.lite || null == t || (t.clarityOverrides = t.clarityOverrides || {}, t.CSSStyleSheet && t.CSSStyleSheet.prototype && (void 0 === t.clarityOverrides.replace && (t.clarityOverrides.replace = t.CSSStyleSheet.prototype.replace, t.CSSStyleSheet.prototype.replace = function() {
            return Go() && gn.indexOf(this[fn]) > -1 && Sn(d(), this[fn], 1, arguments[0]), t.clarityOverrides.replace.apply(this, arguments)
        }), void 0 === t.clarityOverrides.replaceSync && (t.clarityOverrides.replaceSync = t.CSSStyleSheet.prototype.replaceSync, t.CSSStyleSheet.prototype.replaceSync = function() {
            return Go() && gn.indexOf(this[fn]) > -1 && Sn(d(), this[fn], 2, arguments[0]), t.clarityOverrides.replaceSync.apply(this, arguments)
        })))
    }

    function yn() {
        mn(window)
    }

    function bn(t, e) {
        if ((!u.lean || !u.lite) && (-1 === vn.indexOf(t) && (vn.push(t), t.defaultView && mn(t.defaultView)), e = e || d(), null == t ? void 0 : t.adoptedStyleSheets)) {
            for (var n = [], a = 0, r = t.adoptedStyleSheets; a < r.length; a++) {
                var i = r[a];
                i[fn] && -1 !== gn.indexOf(i[fn]) || (i[fn] = yo(), gn.push(i[fn]), Sn(e, i[fn], 0), Sn(e, i[fn], 2, ka(i))), n.push(i[fn])
            }
            var o = Ba(t, !0);
            pn[o] || (pn[o] = []),
                function(t, e) {
                    if (t.length !== e.length) return !1;
                    return t.every((function(t, n) {
                        return t === e[n]
                    }))
                }(n, pn[o]) || (! function(t, e, n, a) {
                    dn.push({
                        time: t,
                        event: 45,
                        data: {
                            id: e,
                            operation: n,
                            newIds: a
                        }
                    }), zn(45)
                }(e, t == document ? -1 : Ba(t), 3, n), pn[o] = n, hn[o] = e)
        }
    }

    function wn() {
        dn = [], ln = []
    }

    function Sn(t, e, n, a) {
        ln.push({
            time: t,
            event: 46,
            data: {
                id: e,
                operation: n,
                cssRules: a
            }
        }), zn(46)
    }
    var kn = [],
        On = null,
        En = null,
        Tn = null,
        _n = null,
        Nn = null,
        Mn = null,
        xn = "clarityAnimationId",
        In = "clarityOperationCount",
        Cn = 20;

    function Dn() {
        kn = []
    }

    function Pn(t, e, n, a, r, i, o) {
        kn.push({
            time: t,
            event: 44,
            data: {
                id: e,
                operation: n,
                keyFrames: a,
                timing: r,
                targetId: i,
                timeline: o
            }
        }), zn(44)
    }

    function Rn(t, e) {
        null === t && (t = Animation.prototype[e], Animation.prototype[e] = function() {
            return An(this, e), t.apply(this, arguments)
        })
    }

    function An(t, e) {
        if (Go()) {
            var n = t.effect,
                a = (null == n ? void 0 : n.target) ? Ba(n.target) : null;
            if (null !== a && n.getKeyframes && n.getTiming) {
                if (!t[xn]) {
                    t[xn] = yo(), t[In] = 0;
                    var r = n.getKeyframes(),
                        i = n.getTiming();
                    Pn(d(), t[xn], 0, JSON.stringify(r), JSON.stringify(i), a)
                }
                if (t[In]++ < Cn) {
                    var o = null;
                    switch (e) {
                        case "play":
                            o = 1;
                            break;
                        case "pause":
                            o = 2;
                            break;
                        case "cancel":
                            o = 3;
                            break;
                        case "finish":
                            o = 4;
                            break;
                        case "commitStyles":
                            o = 5
                    }
                    o && Pn(d(), t[xn], o)
                }
            }
        }
    }
    var Yn, jn = [],
        Xn = new Set;

    function Ln(t) {
        Xn.has(t) || (Xn.add(t), jn.push(t), ki(zn.bind(this, 51)))
    }

    function Wn() {
        jn.length = 0
    }

    function zn(t, e, n) {
        return void 0 === e && (e = null), void 0 === n && (n = null), pt(this, void 0, void 0, (function() {
            var a, r, i, o, c, s, l, f, p, h, v, g, m, y, b, S, k, O, E, T, _, N, M, x, I, P, R, A, Y, j, X, L;
            return ht(this, (function(W) {
                switch (W.label) {
                    case 0:
                        switch (a = n || d(), r = [a, t], t) {
                            case 8:
                                return [3, 1];
                            case 7:
                                return [3, 2];
                            case 45:
                            case 46:
                                return [3, 3];
                            case 44:
                                return [3, 4];
                            case 5:
                            case 6:
                                return [3, 5];
                            case 51:
                                return [3, 12]
                        }
                        return [3, 13];
                    case 1:
                        return i = Yn, r.push(i.width), r.push(i.height), C(t, i.width, i.height), ni(r), [3, 13];
                    case 2:
                        for (o = 0, c = fr; o < c.length; o++) s = c[o], (r = [s.time, 7]).push(s.data.id), r.push(s.data.interaction), r.push(s.data.visibility), r.push(s.data.name), ni(r, !1);
                        return Er(), [3, 13];
                    case 3:
                        for (l = 0, f = dn; l < f.length; l++) m = f[l], (r = [m.time, m.event]).push(m.data.id), r.push(m.data.operation), r.push(m.data.newIds), ni(r);
                        for (p = 0, h = ln; p < h.length; p++) m = h[p], (r = [m.time, m.event]).push(m.data.id), r.push(m.data.operation), r.push(m.data.cssRules), ni(r, !1);
                        return wn(), [3, 13];
                    case 4:
                        for (v = 0, g = kn; v < g.length; v++) m = g[v], (r = [m.time, m.event]).push(m.data.id), r.push(m.data.operation), r.push(m.data.keyFrames), r.push(m.data.timing), r.push(m.data.timeline), r.push(m.data.targetId), ni(r);
                        return Dn(), [3, 13];
                    case 5:
                        if (2 === Ei(e)) return [3, 13];
                        if (!((y = cr()).length > 0)) return [3, 11];
                        b = 0, S = y, W.label = 6;
                    case 6:
                        return b < S.length ? (k = S[b], 0 !== (O = Ei(e)) ? [3, 8] : [4, Ni(e)]) : [3, 10];
                    case 7:
                        O = W.sent(), W.label = 8;
                    case 8:
                        if (2 === O) return [3, 10];
                        for (E = k.data, T = k.metadata.active, _ = k.metadata.suspend, N = k.metadata.privacy, M = function(t) {
                                var e = t.metadata.privacy;
                                return "*T" === t.data.tag && !(0 === e || 1 === e)
                            }(k), x = 0, I = T ? ["tag", "attributes", "value"] : ["tag"]; x < I.length; x++)
                            if (E[P = I[x]] || "" === E[P]) switch (P) {
                                case "tag":
                                    R = Hn(k), A = M ? -1 : 1, r.push(k.id * A), k.parent && T && (r.push(k.parent), k.previous && r.push(k.previous)), r.push(_ ? "*M" : E[P]), R && 2 === R.length && r.push("".concat("#").concat(qn(R[0]), ".").concat(qn(R[1])));
                                    break;
                                case "attributes":
                                    for (Y in E[P]) void 0 !== E[P][Y] && r.push(Un(Y, E[P][Y], N));
                                    break;
                                case "value":
                                    Gt(k.metadata.fraud, k.id, E[P]), r.push(w(E[P], E.tag, N, M))
                            }
                        W.label = 9;
                    case 9:
                        return b++, [3, 6];
                    case 10:
                        6 === t && D(a), ni(sn(r), !u.lean), W.label = 11;
                    case 11:
                        return [3, 13];
                    case 12:
                        for (j = 0, X = jn; j < X.length; j++) L = X[j], ni([a, 51, L]);
                        return Wn(), [3, 13];
                    case 13:
                        return [2]
                }
            }))
        }))
    }

    function Hn(t) {
        if (null !== t.metadata.size && 0 === t.metadata.size.length) {
            var e = ar(t.id);
            if (e) return [Math.floor(100 * e.offsetWidth), Math.floor(100 * e.offsetHeight)]
        }
        return t.metadata.size
    }

    function qn(t) {
        return t.toString(36)
    }

    function Un(t, e, n) {
        return "".concat(t, "=").concat(w(e, 0 === t.indexOf("data-") ? "data-" : t, n))
    }

    function Fn() {
        Yn = null
    }

    function Vn() {
        var t = document.body,
            e = document.documentElement,
            n = t ? t.clientWidth : null,
            a = t ? t.scrollWidth : null,
            r = t ? t.offsetWidth : null,
            i = e ? e.clientWidth : null,
            o = e ? e.scrollWidth : null,
            u = e ? e.offsetWidth : null,
            c = Math.max(n, a, r, i, o, u),
            s = t ? t.clientHeight : null,
            l = t ? t.scrollHeight : null,
            d = t ? t.offsetHeight : null,
            f = e ? e.clientHeight : null,
            p = e ? e.scrollHeight : null,
            h = e ? e.offsetHeight : null,
            v = Math.max(s, l, d, f, p, h);
        null !== Yn && c === Yn.width && v === Yn.height || null === c || null === v || (Yn = {
            width: c,
            height: v
        }, zn(8))
    }

    function Bn(t, e, n, a) {
        return pt(this, void 0, void 0, (function() {
            var r, i, o, u, c;
            return ht(this, (function(s) {
                switch (s.label) {
                    case 0:
                        r = [t], s.label = 1;
                    case 1:
                        if (!(r.length > 0)) return [3, 4];
                        for (i = r.shift(), o = i.firstChild; o;) r.push(o), o = o.nextSibling;
                        return 0 !== (u = Ei(e)) ? [3, 3] : [4, Ni(e)];
                    case 2:
                        u = s.sent(), s.label = 3;
                    case 3:
                        return 2 === u ? [3, 4] : ((c = ya(i, n, a)) && r.push(c), [3, 1]);
                    case 4:
                        return [2]
                }
            }))
        }))
    }
    var Jn = new Set,
        Gn = [],
        Kn = {},
        Zn = [],
        Qn = null,
        $n = null,
        ta = null,
        ea = {},
        na = new WeakMap,
        aa = ["data-google-query-id", "data-load-complete", "data-google-container-id"];

    function ra() {
        Jn = new Set, Zn = [], Qn = null, ta = 0, ea = {}, na = new WeakMap, fa(window)
    }

    function ia(t) {
        var e = d();
        st(6, e), Gn.push({
            time: e,
            mutations: t
        }), ki(ua, 1).then((function() {
            tt(Vn), Co(wr)()
        }))
    }

    function oa(t, e, n, a) {
        return pt(this, void 0, void 0, (function() {
            var r, i, o;
            return ht(this, (function(c) {
                switch (c.label) {
                    case 0:
                        return 0 !== (r = Ei(t)) ? [3, 2] : [4, Ni(t)];
                    case 1:
                        r = c.sent(), c.label = 2;
                    case 2:
                        if (2 === r) return [2];
                        switch (i = e.target, o = u.throttleDom ? function(t, e, n, a) {
                            var r = t.target ? ir(t.target.parentNode) : null;
                            if (r && "HTML" !== r.data.tag) {
                                var i = a > ta,
                                    o = ir(t.target),
                                    u = o && o.selector ? o.selector.join() : t.target.nodeName,
                                    c = [r.selector ? r.selector.join() : "", u, t.attributeName, ca(t.addedNodes), ca(t.removedNodes)].join();
                                ea[c] = c in ea ? ea[c] : [0, n];
                                var s = ea[c];
                                if (!1 === i && s[0] >= 10 && sa(s[2], 2, e, a), s[0] = i ? s[1] === n ? s[0] : s[0] + 1 : 1, s[1] = n, s[0] >= 10) return s[2] = t.removedNodes, n > a + 3e3 ? t.type : (Kn[c] = {
                                    mutation: t,
                                    timestamp: a
                                }, "throttle")
                            }
                            return t.type
                        }(e, t, n, a) : e.type, o && i && i.ownerDocument && Va(i.ownerDocument), o && i && i.nodeType == Node.DOCUMENT_FRAGMENT_NODE && i.host && Va(i), o) {
                            case "attributes":
                                aa.indexOf(e.attributeName) < 0 && ya(i, 3, a);
                                break;
                            case "characterData":
                                ya(i, 4, a);
                                break;
                            case "childList":
                                sa(e.addedNodes, 1, t, a), sa(e.removedNodes, 2, t, a)
                        }
                        return [2]
                }
            }))
        }))
    }

    function ua() {
        return pt(this, void 0, void 0, (function() {
            var t, e, n, a, r, i, o, u, c, s, l;
            return ht(this, (function(f) {
                switch (f.label) {
                    case 0:
                        Ti(t = {
                            id: uo(),
                            cost: 3
                        }), f.label = 1;
                    case 1:
                        if (!(Gn.length > 0)) return [3, 7];
                        e = Gn.shift(), n = d(), a = 0, r = e.mutations, f.label = 2;
                    case 2:
                        return a < r.length ? (i = r[a], [4, oa(t, i, n, e.time)]) : [3, 5];
                    case 3:
                        f.sent(), f.label = 4;
                    case 4:
                        return a++, [3, 2];
                    case 5:
                        return [4, zn(6, t, e.time)];
                    case 6:
                        return f.sent(), [3, 1];
                    case 7:
                        o = !1, u = 0, c = Object.keys(Kn), f.label = 8;
                    case 8:
                        return u < c.length ? (s = c[u], l = Kn[s], delete Kn[s], [4, oa(t, l.mutation, d(), l.timestamp)]) : [3, 11];
                    case 9:
                        f.sent(), o = !0, f.label = 10;
                    case 10:
                        return u++, [3, 8];
                    case 11:
                        return Object.keys(Kn).length > 0 && function() {
                            $n && et($n);
                            $n = tt((function() {
                                ki(ua, 1)
                            }), 33)
                        }(), 0 === Object.keys(Kn).length && o ? [4, zn(6, t, d())] : [3, 13];
                    case 12:
                        f.sent(), f.label = 13;
                    case 13:
                        return function() {
                            var t = d();
                            Object.keys(ea).length > 1e4 && (ea = {}, Z(38));
                            for (var e = 0, n = Object.keys(ea); e < n.length; e++) {
                                var a = n[e];
                                t > ea[a][1] + 3e4 && delete ea[a]
                            }
                        }(), _i(t), [2]
                }
            }))
        }))
    }

    function ca(t) {
        for (var e = [], n = 0; t && n < t.length; n++) e.push(t[n].nodeName);
        return e.join()
    }

    function sa(t, e, n, a) {
        return pt(this, void 0, void 0, (function() {
            var r, i, o, u;
            return ht(this, (function(c) {
                switch (c.label) {
                    case 0:
                        r = t ? t.length : 0, i = 0, c.label = 1;
                    case 1:
                        return i < r ? (o = t[i], 1 !== e ? [3, 2] : (Bn(o, n, e, a), [3, 5])) : [3, 6];
                    case 2:
                        return 0 !== (u = Ei(n)) ? [3, 4] : [4, Ni(n)];
                    case 3:
                        u = c.sent(), c.label = 4;
                    case 4:
                        if (2 === u) return [3, 6];
                        ya(o, e, a), c.label = 5;
                    case 5:
                        return i++, [3, 1];
                    case 6:
                        return [2]
                }
            }))
        }))
    }

    function la(t) {
        return Zn.indexOf(t) < 0 && Zn.push(t), Qn && et(Qn), Qn = tt((function() {
            ! function() {
                for (var t = 0, e = Zn; t < e.length; t++) {
                    var n = e[t];
                    if (n) {
                        var a = n.nodeType === Node.DOCUMENT_FRAGMENT_NODE;
                        if (a && ur(n)) continue;
                        da(n, a ? "childList" : "characterData")
                    }
                }
                Zn = []
            }()
        }), 33), t
    }

    function da(t, e) {
        Co(ia)([{
            addedNodes: [t],
            attributeName: null,
            attributeNamespace: null,
            nextSibling: null,
            oldValue: null,
            previousSibling: null,
            removedNodes: [],
            target: t,
            type: e
        }])
    }

    function fa(t) {
        if (null != t && (t.clarityOverrides = t.clarityOverrides || {}, void 0 === t.clarityOverrides.InsertRule && (t.clarityOverrides.InsertRule = t.CSSStyleSheet.prototype.insertRule, t.CSSStyleSheet.prototype.insertRule = function() {
                return Go() && la(this.ownerNode), t.clarityOverrides.InsertRule.apply(this, arguments)
            }), "CSSMediaRule" in t && void 0 === t.clarityOverrides.MediaInsertRule && (t.clarityOverrides.MediaInsertRule = t.CSSMediaRule.prototype.insertRule, t.CSSMediaRule.prototype.insertRule = function() {
                return Go() && la(this.parentStyleSheet.ownerNode), t.clarityOverrides.MediaInsertRule.apply(this, arguments)
            }), void 0 === t.clarityOverrides.DeleteRule && (t.clarityOverrides.DeleteRule = t.CSSStyleSheet.prototype.deleteRule, t.CSSStyleSheet.prototype.deleteRule = function() {
                return Go() && la(this.ownerNode), t.clarityOverrides.DeleteRule.apply(this, arguments)
            }), "CSSMediaRule" in t && void 0 === t.clarityOverrides.MediaDeleteRule && (t.clarityOverrides.MediaDeleteRule = t.CSSMediaRule.prototype.deleteRule, t.CSSMediaRule.prototype.deleteRule = function() {
                return Go() && la(this.parentStyleSheet.ownerNode), t.clarityOverrides.MediaDeleteRule.apply(this, arguments)
            }), void 0 === t.clarityOverrides.AttachShadow)) {
            t.clarityOverrides.AttachShadow = t.Element.prototype.attachShadow;
            try {
                t.Element.prototype.attachShadow = function() {
                    return Go() ? la(t.clarityOverrides.AttachShadow.apply(this, arguments)) : t.clarityOverrides.AttachShadow.apply(this, arguments)
                }
            } catch (e) {
                t.clarityOverrides.AttachShadow = null
            }
        }
    }
    var pa = /[^0-9\.]/g;

    function ha(t) {
        for (var e = 0, n = Object.keys(t); e < n.length; e++) {
            var a = n[e],
                r = t[a];
            if ("@type" === a && "string" == typeof r) switch (r = (r = r.toLowerCase()).indexOf("article") >= 0 || r.indexOf("posting") >= 0 ? "article" : r) {
                case "article":
                case "recipe":
                    Gi(5, t[a]), Gi(8, t.creator), Gi(18, t.headline);
                    break;
                case "product":
                    Gi(5, t[a]), Gi(10, t.name), Gi(12, t.sku), t.brand && Gi(6, t.brand.name);
                    break;
                case "aggregaterating":
                    t.ratingValue && ($(11, va(t.ratingValue, 100)), $(18, va(t.bestRating)), $(19, va(t.worstRating))), $(12, va(t.ratingCount)), $(17, va(t.reviewCount));
                    break;
                case "offer":
                    Gi(7, t.availability), Gi(14, t.itemCondition), Gi(13, t.priceCurrency), Gi(12, t.sku), $(13, va(t.price));
                    break;
                case "brand":
                    Gi(6, t.name)
            }
            null !== r && "object" == typeof r && ha(r)
        }
    }

    function va(t, e) {
        if (void 0 === e && (e = 1), null !== t) switch (typeof t) {
            case "number":
                return Math.round(t * e);
            case "string":
                return Math.round(parseFloat(t.replace(pa, "")) * e)
        }
        return null
    }
    var ga = ["title", "alt", "onload", "onfocus", "onerror", "data-drupal-form-submit-last", "aria-label"],
        ma = /[\r\n]+/g;

    function ya(e, n, a) {
        var r, i = null;
        if (2 === n && !1 === ur(e)) return i;
        0 !== n && e.nodeType === Node.TEXT_NODE && e.parentElement && "STYLE" === e.parentElement.tagName && (e = e.parentNode);
        var o = !1 === ur(e) ? "add" : "update",
            u = e.parentElement ? e.parentElement : null,
            c = e.ownerDocument !== document;
        switch (e.nodeType) {
            case Node.DOCUMENT_TYPE_NODE:
                u = c && e.parentNode ? Za(e.parentNode) : u;
                var s = e,
                    l = {
                        tag: (c ? "iframe:" : "") + "*D",
                        attributes: {
                            name: s.name ? s.name : "HTML",
                            publicId: s.publicId,
                            systemId: s.systemId
                        }
                    };
                t[o](e, u, l, n);
                break;
            case Node.DOCUMENT_NODE:
                e === document && Va(document), bn(e, a), ba(e);
                break;
            case Node.DOCUMENT_FRAGMENT_NODE:
                var d = e;
                if (d.host) {
                    if (Va(d), "function" === typeof d.constructor && d.constructor.toString().indexOf("[native code]") >= 0) {
                        ba(d);
                        var f = {
                            tag: "*S",
                            attributes: {
                                style: ""
                            }
                        };
                        t[o](e, d.host, f, n)
                    } else t[o](e, d.host, {
                        tag: "*P",
                        attributes: {}
                    }, n);
                    bn(e, a)
                }
                break;
            case Node.TEXT_NODE:
                if (u = u || e.parentNode, "update" === o || u && ur(u) && "STYLE" !== u.tagName && "NOSCRIPT" !== u.tagName) {
                    var p = {
                        tag: "*T",
                        value: e.nodeValue
                    };
                    t[o](e, u, p, n)
                }
                break;
            case Node.ELEMENT_NODE:
                var h = e,
                    v = h.tagName,
                    g = function(t) {
                        var e = {},
                            n = t.attributes;
                        if (n && n.length > 0)
                            for (var a = 0; a < n.length; a++) {
                                var r = n[a].name;
                                ga.indexOf(r) < 0 && (e[r] = n[a].value)
                            }
                        "INPUT" === t.tagName && !("value" in e) && t.value && (e.value = t.value);
                        return e
                    }(h);
                switch (u = e.parentElement ? e.parentElement : e.parentNode ? e.parentNode : null, "http://www.w3.org/2000/svg" === h.namespaceURI && (v = "svg:" + v), v) {
                    case "HTML":
                        u = c && u ? Za(u) : u;
                        var m = {
                            tag: (c ? "iframe:" : "") + v,
                            attributes: g
                        };
                        t[o](e, u, m, n);
                        break;
                    case "SCRIPT":
                        if ("type" in g && "application/ld+json" === g.type) try {
                            ha(JSON.parse(h.text.replace(ma, "")))
                        } catch (t) {}
                        break;
                    case "NOSCRIPT":
                        var y = {
                            tag: v,
                            attributes: {},
                            value: ""
                        };
                        t[o](e, u, y, n);
                        break;
                    case "META":
                        var b = "property" in g ? "property" : "name" in g ? "name" : null;
                        if (b && "content" in g) {
                            var w = g.content;
                            switch (g[b]) {
                                case "og:title":
                                    Gi(20, w);
                                    break;
                                case "og:type":
                                    Gi(19, w);
                                    break;
                                case "generator":
                                    Gi(21, w)
                            }
                        }
                        break;
                    case "HEAD":
                        var S = {
                                tag: v,
                                attributes: g
                            },
                            k = c && (null === (r = e.ownerDocument) || void 0 === r ? void 0 : r.location) ? e.ownerDocument.location : location;
                        S.attributes["*B"] = k.protocol + "//" + k.host + k.pathname, t[o](e, u, S, n);
                        break;
                    case "BASE":
                        var O = ir(e.parentElement);
                        if (O) {
                            var E = document.createElement("a");
                            E.href = g.href, O.data.attributes["*B"] = E.protocol + "//" + E.host + E.pathname
                        }
                        break;
                    case "STYLE":
                        var T = {
                            tag: v,
                            attributes: g,
                            value: Sa(h)
                        };
                        t[o](e, u, T, n);
                        break;
                    case "IFRAME":
                        var _ = e,
                            N = {
                                tag: v,
                                attributes: g
                            };
                        Ka(_) && (! function(t) {
                            !1 === ur(t) && Po(t, "load", da.bind(this, t, "childList"), !0)
                        }(_), N.attributes["*O"] = "true", _.contentDocument && _.contentWindow && "loading" !== _.contentDocument.readyState && (i = _.contentDocument)), 2 === n && wa(_), t[o](e, u, N, n);
                        break;
                    case "LINK":
                        if (to && "stylesheet" === g.rel) {
                            for (var M in Object.keys(document.styleSheets)) {
                                var x = document.styleSheets[M];
                                if (x.ownerNode == h) {
                                    var I = {
                                        tag: "STYLE",
                                        attributes: g,
                                        value: ka(x)
                                    };
                                    t[o](e, u, I, n);
                                    break
                                }
                            }
                            break
                        }
                        var C = {
                            tag: v,
                            attributes: g
                        };
                        t[o](e, u, C, n);
                        break;
                    case "VIDEO":
                    case "AUDIO":
                    case "SOURCE":
                        "src" in g && g.src.startsWith("data:") && (g.src = "");
                        var D = {
                            tag: v,
                            attributes: g
                        };
                        t[o](e, u, D, n);
                        break;
                    default:
                        ! function(t) {
                            var e;
                            (null === (e = window.customElements) || void 0 === e ? void 0 : e.get) && window.customElements.get(t) && Ln(t)
                        }(h.localName);
                        var P = {
                            tag: v,
                            attributes: g
                        };
                        h.shadowRoot && (i = h.shadowRoot), t[o](e, u, P, n)
                }
        }
        return i
    }

    function ba(t) {
        ur(t) || Yo(t) || (! function(t) {
            try {
                var e = c("MutationObserver"),
                    n = e in window ? new window[e](Co(ia)) : null;
                n && (n.observe(t, {
                    attributes: !0,
                    childList: !0,
                    characterData: !0,
                    subtree: !0
                }), na.set(t, n), Jn.add(n)), t.defaultView && fa(t.defaultView)
            } catch (t) {
                hi(2, 0, t ? t.name : null)
            }
        }(t), un(t))
    }

    function wa(t) {
        Ao(t);
        var e, n, a = Qa(t) || {},
            r = a.doc,
            i = void 0 === r ? null : r,
            o = a.win,
            u = void 0 === o ? null : o;
        u && Ao(u), i && (Ao(i), e = i, (n = na.get(e)) && (n.disconnect(), Jn.delete(n), na.delete(e)), $a(t, i))
    }

    function Sa(t) {
        var e = t.textContent ? t.textContent.trim() : "",
            n = t.dataset ? Object.keys(t.dataset).length : 0;
        return (0 === e.length || n > 0 || t.id.length > 0) && (e = ka(t.sheet)), e
    }

    function ka(t) {
        var e = "",
            n = null;
        try {
            n = t ? t.cssRules : []
        } catch (t) {
            if (hi(1, 1, t ? t.name : null), t && "SecurityError" !== t.name) throw t
        }
        if (null !== n)
            for (var a = 0; a < n.length; a++) e += n[a].cssText;
        return e
    }
    var Oa = "load,active,fixed,visible,focus,show,collaps,animat".split(","),
        Ea = {};

    function Ta(t, e) {
        var n = t.attributes,
            a = t.prefix ? t.prefix[e] : null,
            r = 0 === e ? "".concat("~").concat(t.position - 1) : ":nth-of-type(".concat(t.position, ")");
        switch (t.tag) {
            case "STYLE":
            case "TITLE":
            case "LINK":
            case "META":
            case "*T":
            case "*D":
                return "";
            case "HTML":
                return "HTML";
            default:
                if (null === a) return "";
                a = "".concat(a).concat(">"), t.tag = 0 === t.tag.indexOf("svg:") ? t.tag.substr("svg:".length) : t.tag;
                var i = "".concat(a).concat(t.tag).concat(r),
                    o = "id" in n && n.id.length > 0 ? n.id : null,
                    u = "BODY" !== t.tag && "class" in n && n.class.length > 0 ? n.class.trim().split(/\s+/).filter((function(t) {
                        return _a(t)
                    })).join(".") : null;
                if (u && u.length > 0)
                    if (0 === e) {
                        var c = "".concat(function(t) {
                            for (var e = t.split(">"), n = 0; n < e.length; n++) {
                                var a = e[n].indexOf("~"),
                                    r = e[n].indexOf(".");
                                e[n] = e[n].substring(0, r > 0 ? r : a > 0 ? a : e[n].length)
                            }
                            return e.join(">")
                        }(a)).concat(t.tag).concat(".").concat(u);
                        c in Ea || (Ea[c] = []), Ea[c].indexOf(t.id) < 0 && Ea[c].push(t.id), i = "".concat(c).concat("~").concat(Ea[c].indexOf(t.id))
                    } else i = "".concat(a).concat(t.tag, ".").concat(u).concat(r);
                return i = o && _a(o) ? "".concat(function(t) {
                    var e = t.lastIndexOf("*S"),
                        n = t.lastIndexOf("".concat("iframe:").concat("HTML")),
                        a = Math.max(e, n);
                    if (a < 0) return "";
                    return t.substring(0, t.indexOf(">", a) + 1)
                }(a)).concat("#").concat(o) : i, i
        }
    }

    function _a(t) {
        if (!t) return !1;
        if (Oa.some((function(e) {
                return t.toLowerCase().indexOf(e) >= 0
            }))) return !1;
        for (var e = 0; e < t.length; e++) {
            var n = t.charCodeAt(e);
            if (n >= 48 && n <= 57) return !1
        }
        return !0
    }
    var Na = 1,
        Ma = null,
        xa = [],
        Ia = [],
        Ca = {},
        Da = [],
        Pa = [],
        Ra = [],
        Aa = [],
        Ya = [],
        ja = [],
        Xa = null,
        La = null,
        Wa = null,
        za = null,
        Ha = null;

    function qa() {
        Fa(), Va(document, !0)
    }

    function Ua() {
        Fa()
    }

    function Fa() {
        Na = 1, xa = [], Ia = [], Ca = {}, Da = [], Pa = [], Ra = "address,password,contact".split(","), Aa = "password,secret,pass,social,ssn,code,hidden".split(","), Ya = "radio,checkbox,range,button,reset,submit".split(","), ja = "INPUT,SELECT,TEXTAREA".split(","), Ma = new Map, Xa = new WeakMap, La = new WeakMap, Wa = new WeakMap, za = new WeakMap, Ha = new WeakMap, Ea = {}
    }

    function Va(t, e) {
        void 0 === e && (e = !1);
        try {
            e && u.unmask.forEach((function(t) {
                return t.indexOf("!") < 0 ? Pa.push(t) : Da.push(t.substr(1))
            })), "querySelectorAll" in t && (u.regions.forEach((function(e) {
                return t.querySelectorAll(e[1]).forEach((function(t) {
                    return yr(t, "".concat(e[0]))
                }))
            })), u.mask.forEach((function(e) {
                return t.querySelectorAll(e).forEach((function(t) {
                    return za.set(t, 3)
                }))
            })), u.checksum.forEach((function(e) {
                return t.querySelectorAll(e[1]).forEach((function(t) {
                    return Ha.set(t, e[0])
                }))
            })), Pa.forEach((function(e) {
                return t.querySelectorAll(e).forEach((function(t) {
                    return za.set(t, 0)
                }))
            })))
        } catch (t) {
            hi(5, 1, t ? t.name : null)
        }
    }

    function Ba(t, e) {
        if (void 0 === e && (e = !1), null === t) return null;
        var n = Xa.get(t);
        return !n && e && (n = Na++, Xa.set(t, n)), n || null
    }

    function Ja(t, e, n, a) {
        var r = e ? Ba(e) : null;
        if (e && r || null != t.host || t.nodeType === Node.DOCUMENT_TYPE_NODE) {
            var i = Ba(t, !0),
                o = lr(t),
                c = null,
                s = br(t) ? i : null,
                l = Ha.has(t) ? Ha.get(t) : null,
                d = u.content ? 1 : 3;
            r >= 0 && xa[r] && ((c = xa[r]).children.push(i), s = null === s ? c.region : s, l = null === l ? c.metadata.fraud : l, d = c.metadata.privacy), n.attributes && "data-clarity-region" in n.attributes && (yr(t, n.attributes["data-clarity-region"]), s = i), Ma.set(i, t), xa[i] = {
                    id: i,
                    parent: r,
                    previous: o,
                    children: [],
                    data: n,
                    selector: null,
                    hash: null,
                    region: s,
                    metadata: {
                        active: !0,
                        suspend: !1,
                        privacy: d,
                        position: null,
                        fraud: l,
                        size: null
                    }
                },
                function(t, e, n) {
                    var a, r = e.data,
                        i = e.metadata,
                        o = i.privacy,
                        u = r.attributes || {},
                        c = r.tag.toUpperCase();
                    switch (!0) {
                        case ja.indexOf(c) >= 0:
                            var s = u.type,
                                l = "",
                                d = ["class", "style"];
                            Object.keys(u).filter((function(t) {
                                return !d.includes(t)
                            })).forEach((function(t) {
                                return l += u[t].toLowerCase()
                            }));
                            var f = Aa.some((function(t) {
                                return l.indexOf(t) >= 0
                            }));
                            i.privacy = "INPUT" === c && Ya.indexOf(s) >= 0 ? o : f ? 4 : 2;
                            break;
                        case "data-clarity-mask" in u:
                            i.privacy = 3;
                            break;
                        case "data-clarity-unmask" in u:
                            i.privacy = 0;
                            break;
                        case za.has(t):
                            i.privacy = za.get(t);
                            break;
                        case Ha.has(t):
                            i.privacy = 2;
                            break;
                        case "*T" === c:
                            var p = n && n.data ? n.data.tag : "",
                                h = n && n.selector ? n.selector[1] : "",
                                v = ["STYLE", "TITLE", "svg:style"];
                            i.privacy = v.includes(p) || Da.some((function(t) {
                                return h.indexOf(t) >= 0
                            })) ? 0 : o;
                            break;
                        case 1 === o:
                            i.privacy = function(t, e, n) {
                                if (t && e.some((function(e) {
                                        return t.indexOf(e) >= 0
                                    }))) return 2;
                                return n.privacy
                            }(u.class, Ra, i);
                            break;
                        case "IMG" === c:
                            (null === (a = u.src) || void 0 === a ? void 0 : a.startsWith("blob:")) && (i.privacy = 3)
                    }
                }(t, xa[i], c), er(xa[i]),
                function(t) {
                    if ("IMG" === t.data.tag && 3 === t.metadata.privacy) {
                        var e = ar(t.id);
                        !e || e.complete && 0 !== e.naturalWidth || Po(e, "load", (function() {
                            e.setAttribute("data-clarity-loaded", "".concat(yo()))
                        })), t.metadata.size = []
                    }
                }(xa[i]), dr(i, a)
        }
    }

    function Ga(t, e, n, a) {
        var r = Ba(t),
            i = e ? Ba(e) : null,
            o = lr(t),
            u = !1,
            c = !1;
        if (r in xa) {
            var s = xa[r];
            if (s.metadata.active = !0, s.previous !== o && (u = !0, s.previous = o), s.parent !== i) {
                u = !0;
                var l = s.parent;
                if (s.parent = i, null !== i && i >= 0) {
                    var d = null === o ? 0 : xa[i].children.indexOf(o) + 1;
                    xa[i].children.splice(d, 0, r), s.region = br(t) ? r : xa[i].region
                } else ! function(t, e) {
                    if (t in xa) {
                        var n = xa[t];
                        n.metadata.active = !1, n.parent = null, dr(t, e), sr(t)
                    }
                }(r, a);
                if (null !== l && l >= 0) {
                    var f = xa[l].children.indexOf(r);
                    f >= 0 && xa[l].children.splice(f, 1)
                }
                c = !0
            }
            for (var p in n) tr(s.data, n, p) && (u = !0, s.data[p] = n[p]);
            er(s), dr(r, a, u, c)
        }
    }

    function Ka(t) {
        var e = !1;
        if (t.nodeType === Node.ELEMENT_NODE && "IFRAME" === t.tagName) {
            var n = t;
            try {
                n.contentDocument && (La.set(n.contentDocument, n), Wa.set(n, {
                    doc: n.contentDocument,
                    win: n.contentWindow
                }), e = !0)
            } catch (t) {}
        }
        return e
    }

    function Za(t) {
        var e = t.nodeType === Node.DOCUMENT_NODE ? t : null;
        return e && La.has(e) ? La.get(e) : null
    }

    function Qa(t) {
        return Wa.has(t) ? Wa.get(t) : null
    }

    function $a(t, e) {
        Wa.delete(t), La.delete(e)
    }

    function tr(t, e, n) {
        if ("object" == typeof t[n] && "object" == typeof e[n]) {
            for (var a in t[n])
                if (t[n][a] !== e[n][a]) return !0;
            for (var a in e[n])
                if (e[n][a] !== t[n][a]) return !0;
            return !1
        }
        return t[n] !== e[n]
    }

    function er(t) {
        var e = t.parent && t.parent in xa ? xa[t.parent] : null,
            n = e ? e.selector : null,
            a = t.data,
            r = function(t, e) {
                e.metadata.position = 1;
                for (var n = t ? t.children.indexOf(e.id) : -1; n-- > 0;) {
                    var a = xa[t.children[n]];
                    if (e.data.tag === a.data.tag) {
                        e.metadata.position = a.metadata.position + 1;
                        break
                    }
                }
                return e.metadata.position
            }(e, t),
            i = {
                id: t.id,
                tag: a.tag,
                prefix: n,
                position: r,
                attributes: a.attributes
            };
        t.selector = [Ta(i, 0), Ta(i, 1)], t.hash = t.selector.map((function(t) {
            return t ? p(t) : null
        })), t.hash.forEach((function(e) {
            return Ca[e] = t.id
        }))
    }

    function nr(t) {
        var e = ar(or(t));
        return null !== e && null !== e.textContent ? e.textContent.substr(0, 25) : ""
    }

    function ar(t) {
        return Ma.has(t) ? Ma.get(t) : null
    }

    function rr(t) {
        return t in xa ? xa[t] : null
    }

    function ir(t) {
        var e = Ba(t);
        return e in xa ? xa[e] : null
    }

    function or(t) {
        return t in Ca ? Ca[t] : null
    }

    function ur(t) {
        return Ma.has(Ba(t))
    }

    function cr() {
        for (var t = [], e = 0, n = Ia; e < n.length; e++) {
            var a = n[e];
            a in xa && t.push(xa[a])
        }
        return Ia = [], t
    }

    function sr(t) {
        var e = Ma.get(t);
        if ((null == e ? void 0 : e.nodeType) !== Node.DOCUMENT_FRAGMENT_NODE) {
            if (e && (null == e ? void 0 : e.nodeType) === Node.ELEMENT_NODE && "IFRAME" === e.tagName) wa(e);
            Ma.delete(t);
            var n = t in xa ? xa[t] : null;
            if (n && n.children)
                for (var a = 0, r = n.children; a < r.length; a++) {
                    sr(r[a])
                }
        }
    }

    function lr(t) {
        for (var e = null; null === e && t.previousSibling;) e = Ba(t.previousSibling), t = t.previousSibling;
        return e
    }

    function dr(t, e, n, a) {
        if (void 0 === n && (n = !0), void 0 === a && (a = !1), !u.lean || !u.lite) {
            var r = Ia.indexOf(t);
            r >= 0 && 1 === e && a ? (Ia.splice(r, 1), Ia.push(t)) : -1 === r && n && Ia.push(t)
        }
    }
    var fr = [],
        pr = null,
        hr = {},
        vr = [],
        gr = !1,
        mr = null;

    function yr(t, e) {
        !1 === pr.has(t) && (pr.set(t, e), (mr = null === mr && gr ? new IntersectionObserver(Sr, {
            threshold: [0, .05, .1, .2, .3, .4, .5, .6, .7, .8, .9, 1]
        }) : mr) && t && t.nodeType === Node.ELEMENT_NODE && mr.observe(t))
    }

    function br(t) {
        return pr && pr.has(t)
    }

    function wr() {
        for (var t = [], e = 0, n = vr; e < n.length; e++) {
            var a = n[e],
                r = Ba(a.node);
            r ? (a.state.data.id = r, hr[r] = a.state.data, fr.push(a.state)) : t.push(a)
        }
        vr = t, fr.length > 0 && zn(7)
    }

    function Sr(t) {
        for (var e = 0, n = t; e < n.length; e++) {
            var a = n[e],
                r = a.target,
                i = a.boundingClientRect,
                o = a.intersectionRect,
                u = a.rootBounds;
            if (pr.has(r) && i.width + i.height > 0 && u && u.width > 0 && u.height > 0) {
                var c = r ? Ba(r) : null,
                    s = c in hr ? hr[c] : {
                        id: c,
                        name: pr.get(r),
                        interaction: 16,
                        visibility: 0
                    },
                    l = (o ? o.width * o.height * 1 / (u.width * u.height) : 0) > .05 || a.intersectionRatio > .8,
                    d = (l || 10 == s.visibility) && Math.abs(i.top) + u.height > i.height;
                kr(r, s, s.interaction, d ? 13 : l ? 10 : 0), s.visibility >= 13 && mr && mr.unobserve(r)
            }
        }
        fr.length > 0 && zn(7)
    }

    function kr(t, e, n, a) {
        var r = n > e.interaction || a > e.visibility;
        e.interaction = n > e.interaction ? n : e.interaction, e.visibility = a > e.visibility ? a : e.visibility, e.id ? (e.id in hr && r || !(e.id in hr)) && (hr[e.id] = e, fr.push(Or(e))) : vr.push({
            node: t,
            state: Or(e)
        })
    }

    function Or(t) {
        return {
            time: d(),
            data: {
                id: t.id,
                interaction: t.interaction,
                visibility: t.visibility,
                name: t.name
            }
        }
    }

    function Er() {
        fr = []
    }

    function Tr(t) {
        var e = t.composed && t.composedPath ? t.composedPath() : null,
            n = e && e.length > 0 ? e[0] : t.target;
        return ta = d() + 3e3, n && n.nodeType === Node.DOCUMENT_NODE ? n.documentElement : n
    }

    function _r(t, e, n) {
        void 0 === n && (n = null);
        var a = {
            id: 0,
            hash: null,
            privacy: 2
        };
        if (t) {
            var r = ir(t);
            if (null !== r) {
                var i = r.metadata;
                a.id = r.id, a.hash = r.hash, a.privacy = i.privacy, r.region && function(t, e) {
                    var n = ar(t),
                        a = t in hr ? hr[t] : {
                            id: t,
                            visibility: 0,
                            interaction: 16,
                            name: pr.get(n)
                        },
                        r = 16;
                    switch (e) {
                        case 9:
                            r = 20;
                            break;
                        case 27:
                            r = 30
                    }
                    kr(n, a, r, a.visibility)
                }(r.region, e), i.fraud && Gt(i.fraud, r.id, n || r.data.value)
            }
        }
        return a
    }

    function Nr(t, e) {
        return void 0 === e && (e = null), pt(this, void 0, void 0, (function() {
            var n, a, r, i, o, u, c, s, l, f, p, h, v, g, m, y, b, k, O, E, T, _, N, M, x, I, D, R, A, Y, j, X, L, W, z, H;
            return ht(this, (function(q) {
                switch (n = e || d(), a = [n, t], t) {
                    case 13:
                    case 14:
                    case 12:
                    case 15:
                    case 16:
                    case 17:
                    case 18:
                    case 19:
                    case 20:
                        for (r = 0, i = ge; r < i.length; r++) W = i[r], (o = _r(W.data.target, W.event)).id > 0 && ((a = [W.time, W.event]).push(o.id), a.push(W.data.x), a.push(W.data.y), void 0 !== W.data.id && (a.push(W.data.id), void 0 !== W.data.isPrimary && a.push(W.data.isPrimary.toString())), ni(a), (void 0 === W.data.isPrimary || W.data.isPrimary) && C(W.event, W.data.x, W.data.y, W.time));
                        Te();
                        break;
                    case 9:
                    case 48:
                        for (u = 0, c = ee; u < c.length; u++) W = c[u], s = _r(W.data.target, W.event, W.data.text), a = [W.time, W.event], l = s.hash ? s.hash.join(".") : "", a.push(s.id), a.push(W.data.x), a.push(W.data.y), a.push(W.data.eX), a.push(W.data.eY), a.push(W.data.button), a.push(W.data.reaction), a.push(W.data.context), a.push(w(W.data.text, "click", s.privacy)), a.push(S(W.data.link)), a.push(l), a.push(W.data.trust), a.push(W.data.isFullText), a.push(W.data.w), a.push(W.data.h), a.push(W.data.tag), a.push(W.data.class), a.push(W.data.id), ni(a), Cr(W.time, W.event, l, W.data.x, W.data.y, W.data.reaction, W.data.context);
                        oe();
                        break;
                    case 38:
                        for (f = 0, p = ue; f < p.length; f++) W = p[f], a = [W.time, W.event], (j = _r(W.data.target, W.event)).id > 0 && (a.push(j.id), a.push(W.data.action), ni(a));
                        se();
                        break;
                    case 11:
                        h = ve, a.push(h.width), a.push(h.height), C(t, h.width, h.height), De(), ni(a);
                        break;
                    case 26:
                        v = Je, a.push(v.name), a.push(v.persisted), en(), ni(a);
                        break;
                    case 27:
                        for (g = 0, m = de; g < m.length; g++) W = m[g], y = _r(W.data.target, W.event, W.data.value), (a = [W.time, W.event]).push(y.id), a.push(w(W.data.value, "input", y.privacy, !1, W.data.type)), a.push(W.data.trust), ni(a);
                        he();
                        break;
                    case 21:
                        (b = He) && (k = _r(b.start, t), O = _r(b.end, t), a.push(k.id), a.push(b.startOffset), a.push(O.id), a.push(b.endOffset), Be(), ni(a));
                        break;
                    case 10:
                        for (E = 0, T = Pe; E < T.length; E++) W = T[E], _ = _r(W.data.target, W.event), N = _r(W.data.top, W.event), M = _r(W.data.bottom, W.event), x = (null == N ? void 0 : N.hash) ? N.hash.join(".") : "", I = (null == M ? void 0 : M.hash) ? M.hash.join(".") : "", _.id > 0 && ((a = [W.time, W.event]).push(_.id), a.push(W.data.x), a.push(W.data.y), a.push(x), a.push(I), ni(a), C(W.event, W.data.x, W.data.y, W.time));
                        Pe = [], Re = null, Ae = null;
                        break;
                    case 42:
                        for (D = 0, R = Kt; D < R.length; D++) W = R[D], a = [W.time, W.event], (j = _r(W.data.target, W.event)).id > 0 && ((a = [W.time, W.event]).push(j.id), a.push(W.data.type), a.push(w(W.data.value, "change", j.privacy)), a.push(w(W.data.checksum, "checksum", j.privacy)), ni(a));
                        Qt();
                        break;
                    case 39:
                        for (A = 0, Y = Ze; A < Y.length; A++) W = Y[A], a = [W.time, W.event], (j = _r(W.data.target, W.event)).id > 0 && (a.push(j.id), ni(a));
                        $e();
                        break;
                    case 22:
                        for (X = 0, L = xr; X < L.length; X++) W = L[X], (a = [W.time, W.event]).push(W.data.type), a.push(W.data.hash), a.push(W.data.x), a.push(W.data.y), a.push(W.data.reaction), a.push(W.data.context), ni(a, !1);
                        Ir();
                        break;
                    case 28:
                        z = Ge, a.push(z.visible), ni(a), P(n, z.visible), an();
                        break;
                    case 50:
                        H = Ke, a.push(H.focused), ni(a, !1), rn()
                }
                return [2]
            }))
        }))
    }
    var Mr = [],
        xr = [];

    function Ir() {
        xr = []
    }

    function Cr(t, e, n, a, r, i, o) {
        void 0 === i && (i = 1), void 0 === o && (o = 0), Mr.push({
            time: t,
            event: 22,
            data: {
                type: e,
                hash: n,
                x: a,
                y: r,
                reaction: i,
                context: o
            }
        }), C(e, a, r, t)
    }

    function Dr(t, e, n) {
        return "".concat(t, "=").concat(w(e, 0 === t.indexOf("data-") ? "data-" : t, n))
    }
    var Pr = [],
        Rr = 1,
        Ar = null;

    function Yr() {
        Pr = [],
            function(t) {
                var e = [t];
                for (; e.length > 0;) {
                    for (var n = null, a = null, r = null, i = e.shift(), o = i.firstChild, u = i.parentElement ? i.parentElement : i.parentNode ? i.parentNode : null; o;) e.push(o), o = o.nextSibling;
                    switch (i.nodeType) {
                        case Node.DOCUMENT_TYPE_NODE:
                            var c = i;
                            a = "*D", n = {
                                name: c.name,
                                publicId: c.publicId,
                                systemId: c.systemId
                            };
                            break;
                        case Node.TEXT_NODE:
                            r = i.nodeValue, a = Ar.get(u) ? "*T" : a;
                            break;
                        case Node.ELEMENT_NODE:
                            var s = i;
                            n = jr(s), a = ["NOSCRIPT", "SCRIPT", "STYLE"].indexOf(s.tagName) < 0 ? s.tagName : a
                    }
                    Xr(i, u, {
                        tag: a,
                        attributes: n,
                        value: r
                    })
                }
            }(document),
            function(t) {
                pt(this, void 0, void 0, (function() {
                    var e, n, a, r, i, o, u, c, s, l, f, p, h;
                    return ht(this, (function(v) {
                        switch (e = d(), n = [e, t], t) {
                            case 8:
                                a = Yn, n.push(a.width), n.push(a.height), C(t, a.width, a.height), ni(n);
                                break;
                            case 43:
                                if ((r = Pr).length > 0) {
                                    for (i = 0, o = r; i < o.length; i++)
                                        for (u = o[i], c = u.metadata.privacy, s = u.data, l = 0, f = ["tag", "attributes", "value"]; l < f.length; l++)
                                            if (s[p = f[l]]) switch (p) {
                                                case "tag":
                                                    n.push(u.id), u.parent && n.push(u.parent), u.previous && n.push(u.previous), n.push(s[p]);
                                                    break;
                                                case "attributes":
                                                    for (h in s[p]) void 0 !== s[p][h] && n.push(Dr(h, s[p][h], c));
                                                    break;
                                                case "value":
                                                    n.push(w(s[p], s.tag, c))
                                            }
                                    ni(sn(n), !0)
                                }
                        }
                        return [2]
                    }))
                }))
            }(43)
    }

    function jr(t) {
        var e = {},
            n = t.attributes;
        if (n && n.length > 0)
            for (var a = 0; a < n.length; a++) e[n[a].name] = n[a].value;
        return e
    }

    function Xr(t, e, n) {
        if (t && n && n.tag) {
            var a = function(t) {
                    return null === t ? null : Ar.has(t) ? Ar.get(t) : (Ar.set(t, Rr), Rr++)
                }(t),
                r = e ? Ar.get(e) : null,
                i = t.previousSibling ? Ar.get(t.previousSibling) : null;
            Pr.push({
                id: a,
                parent: r,
                previous: i,
                children: [],
                data: n,
                selector: null,
                hash: null,
                region: null,
                metadata: {
                    active: !0,
                    suspend: !1,
                    privacy: 5,
                    position: null,
                    fraud: null,
                    size: null
                }
            })
        }
    }
    var Lr = [],
        Wr = !1,
        zr = null;

    function Hr(t) {
        Wr && "function" == typeof t && Lr.push(t)
    }

    function qr(t) {
        if (Wr) {
            var e = t ? t.split(" ") : [""],
                n = e.length > 1 ? parseInt(e[1], 10) : null;
            n && zr.has(n) || (! function(t) {
                try {
                    var e = document.createElement("script");
                    e.src = t, e.async = !0, document.head.appendChild(e)
                } catch (t) {}
            }(e[0]), n && (zr.add(n), R(zr)))
        }
    }
    var Ur, Fr, Vr, Br, Jr, Gr = Object.freeze({
            __proto__: null,
            event: qr,
            register: Hr,
            start: function() {
                Wr = !0, zr = new Set
            },
            stop: function() {
                Lr.reverse().forEach((function(t) {
                    try {
                        t()
                    } catch (t) {}
                })), Lr = [], Wr = !1
            }
        }),
        Kr = 0,
        Zr = 0,
        Qr = null,
        $r = 0,
        ti = !1;

    function ei() {
        Br = !0, Kr = 0, Zr = 0, ti = !1, $r = 0, Ur = [], Fr = [], Vr = {}, Jr = null
    }

    function ni(t, e) {
        if (void 0 === e && (e = !0), Br) {
            var n = d(),
                a = t.length > 1 ? t[1] : null,
                r = JSON.stringify(t);
            switch (u.lean ? !ti && Zr + r.length > 10485760 && (hi(10, 0), ti = !0) : ti = !1, a) {
                case 5:
                    if (ti) break;
                    Kr += r.length;
                case 37:
                case 6:
                case 43:
                case 45:
                case 46:
                case 44:
                case 51:
                    if (ti) break;
                    Zr += r.length, Ur.push(r);
                    break;
                default:
                    Fr.push(r)
            }
            Z(25);
            var i = function() {
                var t = !1 === u.lean && Kr > 0 ? 100 : To.sequence * u.delay;
                return "string" == typeof u.upload ? Math.max(Math.min(t, 3e4), 100) : u.delay
            }();
            n - $r > 2 * i && (et(Qr), Qr = null), e && null === Qr && (25 !== a && it(), Qr = tt(ri, i), $r = n, Wi(Zr))
        }
    }

    function ai() {
        et(Qr), ri(!0), Kr = 0, Zr = 0, ti = !1, $r = 0, Ur = [], Fr = [], Vr = {}, Jr = null, Br = !1
    }

    function ri(t) {
        return void 0 === t && (t = !1), pt(this, void 0, void 0, (function() {
            var e, n, a, r, i, o, c, s;
            return ht(this, (function(l) {
                switch (l.label) {
                    case 0:
                        return Br ? (Qr = null, (e = !1 === u.lean && Zr > 0 && (Zr < 1048576 || To.sequence > 0)) && $(1, 1), wr(), function() {
                            if (To) {
                                var t = [];
                                xr = [];
                                for (var e = (To.start || 0) + (To.duration || 0), n = Math.max(e - 2e3, 0), a = 0, r = Mr; a < r.length; a++) {
                                    var i = r[a];
                                    i.time >= n && (i.time <= e && xr.push(i), t.push(i))
                                }
                                Mr = t, Nr(22)
                            }
                        }(), Vt(), function() {
                            for (var t = 0, e = vn; t < e.length; t++) {
                                var n = e[t],
                                    a = n == document ? -1 : Ba(n);
                                bn(n, a in hn ? hn[a] : null)
                            }
                        }(), n = !0 === t, To ? (a = JSON.stringify(Mo(n)), r = "[".concat(Fr.join(), "]"), i = e ? "[".concat(Ur.join(), "]") : "", n && i.length > 0 && a.length + r.length + i.length > 65536 && (i = ""), o = function(t) {
                            return t.p.length > 0 ? '{"e":'.concat(t.e, ',"a":').concat(t.a, ',"p":').concat(t.p, "}") : '{"e":'.concat(t.e, ',"a":').concat(t.a, "}")
                        }({
                            e: a,
                            a: r,
                            p: i
                        }), n ? (s = null, [3, 3]) : [3, 1]) : [2]) : [2];
                    case 1:
                        return [4, gt(o)];
                    case 2:
                        s = l.sent(), l.label = 3;
                    case 3:
                        return Q(2, (c = s) ? c.length : o.length), ii(o, c, To.sequence, n), Fr = [], e && (Ur = [], Zr = 0, Kr = 0, ti = !1), [2]
                }
            }))
        }))
    }

    function ii(t, e, n, a) {
        if (void 0 === a && (a = !1), "string" == typeof u.upload) {
            var r = u.upload,
                i = !1;
            if (a && navigator && navigator.sendBeacon) try {
                (i = navigator.sendBeacon.bind(navigator)(r, t)) && ui(n)
            } catch (t) {}
            if (!1 === i) {
                n in Vr ? Vr[n].attempts++ : Vr[n] = {
                    data: t,
                    attempts: 1
                };
                var o = new XMLHttpRequest;
                o.open("POST", r, !0), o.timeout = 15e3, o.ontimeout = function() {
                    Io(new Error("".concat("Timeout", " : ").concat(r)))
                }, null !== n && (o.onreadystatechange = function() {
                    Co(oi)(o, n)
                }), o.withCredentials = !0, e ? (o.setRequestHeader("Accept", "application/x-clarity-gzip"), o.send(e)) : o.send(t)
            }
        } else if (u.upload) {
            (0, u.upload)(t), ui(n)
        }
    }

    function oi(t, e) {
        var n = Vr[e];
        t && 4 === t.readyState && n && ((t.status < 200 || t.status > 208) && n.attempts <= 1 ? t.status >= 400 && t.status < 500 ? zi(6) : (0 === t.status && (u.upload = u.fallback ? u.fallback : u.upload), Jr = {
            sequence: e,
            attempts: n.attempts,
            status: t.status
        }, Xi(2), ii(n.data, null, e)) : (Jr = {
            sequence: e,
            attempts: n.attempts,
            status: t.status
        }, n.attempts > 1 && Xi(2), 200 === t.status && t.responseText && function(t) {
            for (var e = t && t.length > 0 ? t.split("\n") : [], n = 0, a = e; n < a.length; n++) {
                var r = a[n],
                    i = r && r.length > 0 ? r.split(/ (.*)/) : [""];
                switch (i[0]) {
                    case "END":
                        zi(6);
                        break;
                    case "UPGRADE":
                        Yi("Auto");
                        break;
                    case "ACTION":
                        u.action && i.length > 1 && u.action(i[1]);
                        break;
                    case "EXTRACT":
                        i.length > 1 && Pt(i[1]);
                        break;
                    case "SIGNAL":
                        i.length > 1 && Ht(i[1]);
                        break;
                    case "MODULE":
                        i.length > 1 && qr(i[1]);
                        break;
                    case "SNAPSHOT":
                        u.lean = !1, Yr()
                }
            }
        }(t.responseText), 0 === t.status && (ii(n.data, null, e, !0), zi(3)), t.status >= 200 && t.status <= 208 && ui(e), delete Vr[e]))
    }

    function ui(t) {
        1 === t && (vo(), ho())
    }
    var ci, si = {};

    function li(t) {
        var e = t.error || t;
        return e.message in si || (si[e.message] = 0), si[e.message]++ >= 5 || e && e.message && (ci = {
            message: e.message,
            line: t.lineno,
            column: t.colno,
            stack: e.stack,
            source: t.filename
        }, di(31)), !0
    }

    function di(t) {
        return pt(this, void 0, void 0, (function() {
            var e;
            return ht(this, (function(n) {
                switch (e = [d(), t], t) {
                    case 31:
                        e.push(ci.message), e.push(ci.line), e.push(ci.column), e.push(ci.stack), e.push(S(ci.source)), ni(e);
                        break;
                    case 33:
                        fi && (e.push(fi.code), e.push(fi.name), e.push(fi.message), e.push(fi.stack), e.push(fi.severity), ni(e, !1));
                        break;
                    case 41:
                        Bt && (e.push(Bt.id), e.push(Bt.target), e.push(Bt.checksum), ni(e, !1))
                }
                return [2]
            }))
        }))
    }
    var fi, pi = {};

    function hi(t, e, n, a, r) {
        void 0 === n && (n = null), void 0 === a && (a = null), void 0 === r && (r = null);
        var i = n ? "".concat(n, "|").concat(a) : "";
        t in pi && pi[t].indexOf(i) >= 0 || (fi = {
            code: t,
            name: n,
            message: a,
            stack: r,
            severity: e
        }, t in pi ? pi[t].push(i) : pi[t] = [i], di(33))
    }
    var vi = 5e3,
        gi = {},
        mi = [],
        yi = null,
        bi = null,
        wi = null;

    function Si() {
        gi = {}, mi = [], yi = null, bi = null
    }

    function ki(t, e) {
        return void 0 === e && (e = 0), pt(this, void 0, void 0, (function() {
            var n, a, r;
            return ht(this, (function(i) {
                for (n = 0, a = mi; n < a.length; n++)
                    if (a[n].task === t) return [2];
                return r = new Promise((function(n) {
                    mi[1 === e ? "unshift" : "push"]({
                        task: t,
                        resolve: n,
                        id: uo()
                    })
                })), null === yi && null === bi && Oi(), [2, r]
            }))
        }))
    }

    function Oi() {
        var t = mi.shift();
        t && (yi = t, t.task().then((function() {
            t.id === uo() && (t.resolve(), yi = null, Oi())
        })).catch((function(e) {
            t.id === uo() && (e && hi(0, 1, e.name, e.message, e.stack), yi = null, Oi())
        })))
    }

    function Ei(t) {
        var e = Mi(t);
        return e in gi ? performance.now() - gi[e].start > gi[e].yield ? 0 : 1 : 2
    }

    function Ti(t) {
        gi[Mi(t)] = {
            start: performance.now(),
            calls: 0,
            yield: 30
        }
    }

    function _i(t) {
        var e = performance.now(),
            n = Mi(t),
            a = e - gi[n].start;
        Q(t.cost, a), Z(5), gi[n].calls > 0 && Q(4, a)
    }

    function Ni(t) {
        var e;
        return pt(this, void 0, void 0, (function() {
            var n, a;
            return ht(this, (function(r) {
                switch (r.label) {
                    case 0:
                        return (n = Mi(t)) in gi ? (_i(t), a = gi[n], [4, xi()]) : [3, 2];
                    case 1:
                        a.yield = (null === (e = r.sent()) || void 0 === e ? void 0 : e.timeRemaining()) || 30,
                            function(t) {
                                var e = Mi(t);
                                if (gi && gi[e]) {
                                    var n = gi[e].calls,
                                        a = gi[e].yield;
                                    Ti(t), gi[e].calls = n + 1, gi[e].yield = a
                                }
                            }(t), r.label = 2;
                    case 2:
                        return [2, n in gi ? 1 : 2]
                }
            }))
        }))
    }

    function Mi(t) {
        return "".concat(t.id, ".").concat(t.cost)
    }

    function xi() {
        return pt(this, void 0, void 0, (function() {
            return ht(this, (function(t) {
                switch (t.label) {
                    case 0:
                        return bi ? [4, bi] : [3, 2];
                    case 1:
                        t.sent(), t.label = 2;
                    case 2:
                        return [2, new Promise((function(t) {
                            Ii(t, {
                                timeout: vi
                            })
                        }))]
                }
            }))
        }))
    }
    var Ii = window.requestIdleCallback || function(t, e) {
        var n = performance.now(),
            a = new MessageChannel,
            r = a.port1,
            i = a.port2;
        r.onmessage = function(a) {
            var r = performance.now(),
                o = r - n,
                u = r - a.data;
            if (u > 30 && o < e.timeout) requestAnimationFrame((function() {
                i.postMessage(r)
            }));
            else {
                var c = o > e.timeout;
                t({
                    didTimeout: c,
                    timeRemaining: function() {
                        return c ? 30 : Math.max(0, 30 - u)
                    }
                })
            }
        }, requestAnimationFrame((function() {
            i.postMessage(performance.now())
        }))
    };

    function Ci() {
        ki(Di, 1).then((function() {
            Co(Vn)(), Co(wr)(), Co(ze)()
        }))
    }

    function Di() {
        return pt(this, void 0, void 0, (function() {
            var t, e;
            return ht(this, (function(n) {
                switch (n.label) {
                    case 0:
                        return t = d(), Ti(e = {
                            id: uo(),
                            cost: 3
                        }), [4, Bn(document, e, 0, t)];
                    case 1:
                        return n.sent(), bn(document, t), [4, zn(5, e, t)];
                    case 2:
                        return n.sent(), _i(e), [2]
                }
            }))
        }))
    }
    var Pi, Ri = null;

    function Ai() {
        !u.lean && u.upgrade && u.upgrade("Config"), Ri = null
    }

    function Yi(t) {
        Go() && u.lean && (u.lean = !1, Ri = {
            key: t
        }, ho(), vo(), u.upgrade && u.upgrade(t), Xi(3), u.lite && (Ci(), yn()))
    }

    function ji() {
        Ri = null
    }

    function Xi(t) {
        var e = [d(), t];
        switch (t) {
            case 4:
                var n = N;
                n && n.data && ((e = [n.time, n.event]).push(n.data.visible), e.push(n.data.docWidth), e.push(n.data.docHeight), e.push(n.data.screenWidth), e.push(n.data.screenHeight), e.push(n.data.scrollX), e.push(n.data.scrollY), e.push(n.data.pointerX), e.push(n.data.pointerY), e.push(n.data.activityTime), e.push(n.data.scrollTime), e.push(n.data.pointerTime), e.push(n.data.moveX), e.push(n.data.moveY), e.push(n.data.moveTime), e.push(n.data.downX), e.push(n.data.downY), e.push(n.data.downTime), e.push(n.data.upX), e.push(n.data.upY), e.push(n.data.upTime), e.push(n.data.pointerPrevX), e.push(n.data.pointerPrevY), e.push(n.data.pointerPrevTime), e.push(n.data.modules), ni(e, !1)), I();
                break;
            case 25:
                e.push(J.gap), ni(e);
                break;
            case 35:
                e.push(Pi.check), ni(e, !1);
                break;
            case 3:
                e.push(Ri.key), ni(e);
                break;
            case 2:
                e.push(Jr.sequence), e.push(Jr.attempts), e.push(Jr.status), ni(e, !1);
                break;
            case 24:
                V.key && e.push(V.key), e.push(V.value), ni(e);
                break;
            case 34:
                var a = Object.keys(yt);
                if (a.length > 0) {
                    for (var r = 0, i = a; r < i.length; r++) {
                        var o = i[r];
                        e.push(o), e.push(yt[o])
                    }
                    Ot(), ni(e, !1)
                }
                break;
            case 0:
                var u = Object.keys(K);
                if (u.length > 0) {
                    for (var c = 0, s = u; c < s.length; c++) {
                        var l = s[c],
                            f = parseInt(l, 10);
                        e.push(f), e.push(Math.round(K[l]))
                    }
                    K = {}, ni(e, !1)
                }
                break;
            case 1:
                var p = Object.keys(Fi);
                if (p.length > 0) {
                    for (var h = 0, v = p; h < v.length; h++) {
                        var g = v[h];
                        f = parseInt(g, 10);
                        e.push(f), e.push(Fi[g])
                    }
                    Zi(), ni(e, !1)
                }
                break;
            case 36:
                var m = Object.keys(ct);
                if (m.length > 0) {
                    for (var y = 0, b = m; y < b.length; y++) {
                        var w = b[y];
                        f = parseInt(w, 10);
                        e.push(f), e.push([].concat.apply([], ct[w]))
                    }
                    dt(), ni(e, !1)
                }
                break;
            case 40:
                Mt.forEach((function(t) {
                    e.push(t);
                    var n = [];
                    for (var a in Nt[t]) {
                        var r = parseInt(a, 10);
                        n.push(r), n.push(Nt[t][a])
                    }
                    e.push(n)
                })), Yt(), ni(e, !1);
                break;
            case 47:
                e.push(j.source), e.push(j.ad_Storage), e.push(j.analytics_Storage), ni(e, !1)
        }
    }

    function Li() {
        Pi = {
            check: 0
        }
    }

    function Wi(t) {
        if (0 === Pi.check) {
            var e = Pi.check;
            e = To.sequence >= 128 ? 1 : e, e = To.pageNum >= 128 ? 7 : e, e = d() > 72e5 ? 2 : e, (e = t > 10485760 ? 2 : e) !== Pi.check && zi(e)
        }
    }

    function zi(t) {
        Pi.check = t, 5 !== t && (po(), wu())
    }

    function Hi() {
        0 !== Pi.check && Xi(35)
    }

    function qi() {
        Pi = null
    }
    var Ui = null,
        Fi = null,
        Vi = !1;

    function Bi() {
        Ui = {}, Fi = {}, Vi = !1
    }

    function Ji() {
        Ui = {}, Fi = {}, Vi = !1
    }

    function Gi(t, e) {
        if (e && (e = "".concat(e), t in Ui || (Ui[t] = []), Ui[t].indexOf(e) < 0)) {
            if (Ui[t].length > 128) return void(Vi || (Vi = !0, zi(5)));
            Ui[t].push(e), t in Fi || (Fi[t] = []), Fi[t].push(e)
        }
    }

    function Ki() {
        Xi(1)
    }

    function Zi() {
        Fi = {}, Vi = !1
    }
    var Qi = null,
        $i = [],
        to = 0,
        eo = null,
        no = null,
        ao = {
            ad_Storage: "denied",
            analytics_Storage: "denied"
        };

    function ro() {
        var t, e, n;
        eo = null;
        var a = navigator && "userAgent" in navigator ? navigator.userAgent : "",
            r = null !== (n = "undefined" != typeof Intl && (null === (e = null === (t = null === Intl || void 0 === Intl ? void 0 : Intl.DateTimeFormat()) || void 0 === t ? void 0 : t.resolvedOptions()) || void 0 === e ? void 0 : e.timeZone)) && void 0 !== n ? n : "",
            i = (new Date).getTimezoneOffset().toString(),
            o = window.location.ancestorOrigins ? Array.from(window.location.ancestorOrigins).toString() : "",
            c = document && document.title ? document.title : "";
        to = a.indexOf("Electron") > 0 ? 1 : 0;
        var s = function() {
                var t = {
                        session: yo(),
                        ts: Math.round(Date.now()),
                        count: 1,
                        upgrade: null,
                        upload: ""
                    },
                    e = So("_clsk", !u.includeSubdomains);
                if (e) {
                    var n = e.includes("^") ? e.split("^") : e.split("|");
                    n.length >= 5 && t.ts - bo(n[1]) < 18e5 && (t.session = n[0], t.count = bo(n[2]) + 1, t.upgrade = bo(n[3]), t.upload = n.length >= 6 ? "".concat("https://").concat(n[5], "/").concat(n[4]) : "".concat("https://").concat(n[4]))
                }
                return t
            }(),
            l = wo(),
            d = u.projectId || p(location.host);
        Qi = {
            projectId: d,
            userId: l.id,
            sessionId: s.session,
            pageNum: s.count
        }, u.lean = u.track && null !== s.upgrade ? 0 === s.upgrade : u.lean, u.upload = u.track && "string" == typeof u.upload && s.upload && s.upload.length > "https://".length ? s.upload : u.upload, Gi(0, a), Gi(3, c), Gi(1, S(location.href, !!to)), Gi(2, document.referrer), Gi(15, function() {
            var t = yo();
            if (u.track && go(window, "sessionStorage")) {
                var e = sessionStorage.getItem("_cltk");
                t = e || t, sessionStorage.setItem("_cltk", t)
            }
            return t
        }()), Gi(16, document.documentElement.lang), Gi(17, document.dir), Gi(26, "".concat(window.devicePixelRatio)), Gi(28, l.dob.toString()), Gi(29, l.version.toString()), Gi(33, o), Gi(34, r), Gi(35, i), $(0, s.ts), $(1, 0), $(35, to);
        var f, h = null === window || void 0 === window ? void 0 : window.Zone;
        h && "__symbol__" in h && $(39, 1), navigator && (Gi(9, navigator.language), $(33, navigator.hardwareConcurrency), $(32, navigator.maxTouchPoints), $(34, Math.round(navigator.deviceMemory)), (f = navigator.userAgentData) && f.getHighEntropyValues ? f.getHighEntropyValues(["model", "platform", "platformVersion", "uaFullVersion"]).then((function(t) {
            var e;
            Gi(22, t.platform), Gi(23, t.platformVersion), null === (e = t.brands) || void 0 === e || e.forEach((function(t) {
                Gi(24, t.name + "~" + t.version)
            })), Gi(25, t.model), $(27, t.mobile ? 1 : 0)
        })) : Gi(22, navigator.platform)), screen && ($(14, Math.round(screen.width)), $(15, Math.round(screen.height)), $(16, Math.round(screen.colorDepth)));
        for (var v = 0, g = u.cookies; v < g.length; v++) {
            var m = g[v],
                y = So(m);
            y && bt(m, y)
        }
        null === no && (no = {
            ad_Storage: u.track ? "granted" : "denied",
            analytics_Storage: u.track ? "granted" : "denied"
        }), W(lo(no, 0)), mo(l)
    }

    function io() {
        eo = null, Qi = null, $i.forEach((function(t) {
            t.called = !1
        }))
    }

    function oo(t, e, n, a) {
        void 0 === e && (e = !0), void 0 === n && (n = !1), void 0 === a && (a = !1);
        var r = u.lean ? 0 : 1,
            i = !1;
        Qi && (r || !1 === e) && (t(Qi, !u.lean, a ? no : void 0), i = !0), !n && i || $i.push({
            callback: t,
            wait: e,
            recall: n,
            called: i,
            consentInfo: a
        })
    }

    function uo() {
        return Qi ? [Qi.userId, Qi.sessionId, Qi.pageNum].join(".") : ""
    }

    function co(t) {
        void 0 === t && (t = !0), t ? (so({
            ad_Storage: "granted",
            analytics_Storage: "granted"
        }), z()) : so()
    }

    function so(t, e) {
        void 0 === t && (t = ao), void 0 === e && (e = 1);
        var n = {
            ad_Storage: fo(t.ad_Storage),
            analytics_Storage: fo(t.analytics_Storage)
        };
        if (!no || n.ad_Storage !== no.ad_Storage || n.analytics_Storage !== no.analytics_Storage) {
            no = n, ho(!0);
            var a = lo(no, e);
            if (!a.analytics_Storage && u.track) return u.track = !1, Oo("_clsk", "", -Number.MAX_VALUE), Oo("_clck", "", -Number.MAX_VALUE), wu(), void window.setTimeout(bu, 250);
            Go() && a.analytics_Storage && (u.track = !0, mo(wo(), 1), vo()), q(a), z()
        }
    }

    function lo(t, e) {
        return {
            source: e,
            ad_Storage: "granted" === t.ad_Storage ? 1 : 0,
            analytics_Storage: "granted" === t.analytics_Storage ? 1 : 0
        }
    }

    function fo(t) {
        return "string" == typeof t ? t.toLowerCase() : "denied"
    }

    function po() {
        Oo("_clsk", "", 0)
    }

    function ho(t) {
        void 0 === t && (t = !1),
            function(t, e) {
                void 0 === e && (e = !1);
                if ($i.length > 0)
                    for (var n = 0; n < $i.length; n++) {
                        var a = $i[n];
                        a.callback && (!a.called && !e || a.consentInfo && e) && (!a.wait || t) && (a.callback(Qi, !u.lean, a.consentInfo ? no : void 0), a.called = !0, a.recall || ($i.splice(n, 1), n--))
                    }
            }(u.lean ? 0 : 1, t)
    }

    function vo() {
        if (Qi && u.track) {
            var t = Math.round(Date.now()),
                e = u.upload && "string" == typeof u.upload ? u.upload.replace("https://", "") : "",
                n = u.lean ? 0 : 1;
            Oo("_clsk", [Qi.sessionId, t, Qi.pageNum, n, e].join("^"), 1)
        }
    }

    function go(t, e) {
        try {
            return !!t[e]
        } catch (t) {
            return !1
        }
    }

    function mo(t, e) {
        void 0 === e && (e = null), e = null === e ? t.consent : e;
        var n = Math.ceil((Date.now() + 31536e6) / 864e5),
            a = 0 === t.dob ? null === u.dob ? 0 : u.dob : t.dob;
        (null === t.expiry || Math.abs(n - t.expiry) >= 1 || t.consent !== e || t.dob !== a) && Oo("_clck", [Qi.userId, 2, n.toString(36), e, a].join("^"), 365)
    }

    function yo() {
        var t = Math.floor(Math.random() * Math.pow(2, 32));
        return window && window.crypto && window.crypto.getRandomValues && Uint32Array && (t = window.crypto.getRandomValues(new Uint32Array(1))[0]), t.toString(36)
    }

    function bo(t, e) {
        return void 0 === e && (e = 10), parseInt(t, e)
    }

    function wo() {
        var t = {
                id: yo(),
                version: 0,
                expiry: null,
                consent: 0,
                dob: 0
            },
            e = So("_clck", !u.includeSubdomains);
        if (e && e.length > 0) {
            var n = e.includes("^") ? e.split("^") : e.split("|");
            n.length > 1 && (t.version = bo(n[1])), n.length > 2 && (t.expiry = bo(n[2], 36)), n.length > 3 && 1 === bo(n[3]) && (t.consent = 1), n.length > 4 && bo(n[1]) > 1 && (t.dob = bo(n[4])), u.track = u.track || 1 === t.consent, t.id = u.track ? n[0] : t.id
        }
        return t
    }

    function So(t, e) {
        var n;
        if (void 0 === e && (e = !1), go(document, "cookie")) {
            var a = document.cookie.split(";");
            if (a)
                for (var r = 0; r < a.length; r++) {
                    var i = a[r].split("=");
                    if (i.length > 1 && i[0] && i[0].trim() === t) {
                        for (var o = ko(i[1]), u = o[0], c = o[1]; u;) u = (n = ko(c))[0], c = n[1];
                        return e ? c.endsWith("".concat("~", "1")) ? c.substring(0, c.length - 2) : null : c
                    }
                }
        }
        return null
    }

    function ko(t) {
        try {
            var e = decodeURIComponent(t);
            return [e != t, e]
        } catch (t) {}
        return [!1, t]
    }

    function Oo(t, e, n) {
        if ((u.track || "" == e) && (navigator && navigator.cookieEnabled || go(document, "cookie"))) {
            var a = function(t) {
                    return encodeURIComponent(t)
                }(e),
                r = new Date;
            r.setDate(r.getDate() + n);
            var i = r ? "expires=" + r.toUTCString() : "",
                o = "".concat(t, "=").concat(a).concat(";").concat(i).concat(";path=/");
            try {
                if (null === eo) {
                    for (var c = location.hostname ? location.hostname.split(".") : [], s = c.length - 1; s >= 0; s--)
                        if (eo = ".".concat(c[s]).concat(eo || ""), s < c.length - 1 && (document.cookie = "".concat(o).concat(";").concat("domain=").concat(eo), So(t) === e)) return;
                    eo = ""
                }
            } catch (t) {
                eo = ""
            }
            document.cookie = eo ? "".concat(o).concat(";").concat("domain=").concat(eo) : o
        }
    }
    var Eo, To = null;

    function _o() {
        var t = Qi;
        To = {
            version: f,
            sequence: 0,
            start: 0,
            duration: 0,
            projectId: t.projectId,
            userId: t.userId,
            sessionId: t.sessionId,
            pageNum: t.pageNum,
            upload: 0,
            end: 0,
            applicationPlatform: 0,
            url: ""
        }
    }

    function No() {
        To = null
    }

    function Mo(t) {
        return To.start = To.start + To.duration, To.duration = d() - To.start, To.sequence++, To.upload = t && "sendBeacon" in navigator ? 1 : 0, To.end = t ? 1 : 0, To.applicationPlatform = 0, To.url = S(location.href, !1, !0), [To.version, To.sequence, To.start, To.duration, To.projectId, To.userId, To.sessionId, To.pageNum, To.upload, To.end, To.applicationPlatform, To.url]
    }

    function xo() {
        Eo = []
    }

    function Io(t) {
        if (Eo && -1 === Eo.indexOf(t.message)) {
            var e = u.report;
            if (e && e.length > 0 && To) {
                var n = {
                    v: To.version,
                    p: To.projectId,
                    u: To.userId,
                    s: To.sessionId,
                    n: To.pageNum
                };
                t.message && (n.m = t.message), t.stack && (n.e = t.stack);
                var a = new XMLHttpRequest;
                a.open("POST", e, !0), a.send(JSON.stringify(n)), Eo.push(t.message)
            }
        }
        return t
    }

    function Co(t) {
        return function() {
            var e = performance.now();
            try {
                t.apply(this, arguments)
            } catch (t) {
                throw Io(t)
            }
            var n = performance.now() - e;
            Q(4, n), n > 30 && (Z(7), $(6, n), t.dn && hi(9, 0, "".concat(t.dn, "-").concat(n)))
        }
    }
    var Do = new Map;

    function Po(t, e, n, a, r) {
        void 0 === a && (a = !1), void 0 === r && (r = !0), n = Co(n);
        try {
            t[c("addEventListener")](e, n, {
                capture: a,
                passive: r
            }), Yo(t) || Do.set(t, []), Do.get(t).push({
                event: e,
                listener: n,
                options: {
                    capture: a,
                    passive: r
                }
            })
        } catch (t) {}
    }

    function Ro() {
        Do.forEach((function(t, e) {
            jo(t, e)
        })), Do = new Map
    }

    function Ao(t) {
        Yo(t) && jo(Do.get(t), t)
    }

    function Yo(t) {
        return Do.has(t)
    }

    function jo(t, e) {
        t.forEach((function(t) {
            try {
                e[c("removeEventListener")](t.event, t.listener, {
                    capture: t.options.capture,
                    passive: t.options.passive
                })
            } catch (t) {}
        })), Do.delete(e)
    }
    var Xo = null,
        Lo = null,
        Wo = null,
        zo = 0;

    function Ho() {
        return !(zo++ > 20) || (hi(4, 0), !1)
    }

    function qo() {
        zo = 0, Wo !== Fo() && (wu(), window.setTimeout(Uo, 250))
    }

    function Uo() {
        bu(), $(29, 1)
    }

    function Fo() {
        return location.href ? location.href.replace(location.hash, "") : location.href
    }
    var Vo = !1;

    function Bo() {
        Vo = !0, s = l(), Si(), Ro(), xo(), Wo = Fo(), zo = 0, Po(window, "popstate", qo), null === Xo && (Xo = history.pushState, history.pushState = function() {
            Xo.apply(this, arguments), Go() && Ho() && qo()
        }), null === Lo && (Lo = history.replaceState, history.replaceState = function() {
            Lo.apply(this, arguments), Go() && Ho() && qo()
        })
    }

    function Jo() {
        Wo = null, zo = 0, xo(), Ro(), Si(), s = 0, Vo = !1
    }

    function Go() {
        return Vo
    }

    function Ko() {
        bu(), B("clarity", "restart")
    }
    var Zo = Object.freeze({
        __proto__: null,
        start: function() {
            ! function() {
                Jt = [], $(26, navigator.webdriver ? 1 : 0);
                try {
                    $(31, window.top == window.self || window.top == window ? 1 : 2)
                } catch (t) {
                    $(31, 0)
                }
            }(), Po(window, "error", li), si = {}, pi = {}
        },
        stop: function() {
            pi = {}
        }
    });
    var Qo = Object.freeze({
        __proto__: null,
        hashText: nr,
        start: function() {
            var t;
            Fn(), Vn(), Er(), mr = null, pr = new WeakMap, hr = {}, vr = [], gr = !!window.IntersectionObserver, qa(), u.delayDom ? Po(window, "load", (function() {
                    ra()
                })) : ra(), Ci(), yn(),
                function() {
                    if (window.Animation && window.Animation.prototype && window.KeyframeEffect && window.KeyframeEffect.prototype && window.KeyframeEffect.prototype.getKeyframes && window.KeyframeEffect.prototype.getTiming && (Dn(), Rn(En, "play"), Rn(Tn, "pause"), Rn(_n, "commitStyles"), Rn(Nn, "cancel"), Rn(Mn, "finish"), null === On && (On = Element.prototype.animate, Element.prototype.animate = function() {
                            var t = On.apply(this, arguments);
                            return An(t, "play"), t
                        }), document.getAnimations))
                        for (var t = 0, e = document.getAnimations(); t < e.length; t++) {
                            var n = e[t];
                            "finished" === n.playState ? An(n, "finish") : "paused" === n.playState || "idle" === n.playState ? An(n, "pause") : "running" === n.playState && An(n, "play")
                        }
                }(), window.clarityOverrides = window.clarityOverrides || {}, (null === (t = window.customElements) || void 0 === t ? void 0 : t.define) && !window.clarityOverrides.define && (window.clarityOverrides.define = window.customElements.define, window.customElements.define = function() {
                    return Go() && Ln(arguments[0]), window.clarityOverrides.define.apply(this, arguments)
                })
        },
        stop: function() {
            Er(), pr = null, hr = {}, vr = [], mr && (mr.disconnect(), mr = null), gr = !1, Ua(),
                function() {
                    for (var t = 0, e = Array.from(Jn); t < e.length; t++) {
                        var n = e[t];
                        n && n.disconnect()
                    }
                    Jn = new Set, ea = {}, Gn = [], Kn = {}, Zn = [], ta = 0, Qn = null, na = new WeakMap
                }(), Fn(), pn = {}, hn = {}, vn = [], gn = [], wn(), Dn(), Wn(), Xn.clear()
        }
    });
    var $o = null;

    function tu() {
        $o = null
    }

    function eu(t) {
        $o = {
                fetchStart: Math.round(t.fetchStart),
                connectStart: Math.round(t.connectStart),
                connectEnd: Math.round(t.connectEnd),
                requestStart: Math.round(t.requestStart),
                responseStart: Math.round(t.responseStart),
                responseEnd: Math.round(t.responseEnd),
                domInteractive: Math.round(t.domInteractive),
                domComplete: Math.round(t.domComplete),
                loadEventStart: Math.round(t.loadEventStart),
                loadEventEnd: Math.round(t.loadEventEnd),
                redirectCount: Math.round(t.redirectCount),
                size: t.transferSize ? t.transferSize : 0,
                type: t.type,
                protocol: t.nextHopProtocol,
                encodedSize: t.encodedBodySize ? t.encodedBodySize : 0,
                decodedSize: t.decodedBodySize ? t.decodedBodySize : 0
            },
            function(t) {
                pt(this, void 0, void 0, (function() {
                    var e, n;
                    return ht(this, (function(a) {
                        return e = d(), n = [e, t], 29 === t && (n.push($o.fetchStart), n.push($o.connectStart), n.push($o.connectEnd), n.push($o.requestStart), n.push($o.responseStart), n.push($o.responseEnd), n.push($o.domInteractive), n.push($o.domComplete), n.push($o.loadEventStart), n.push($o.loadEventEnd), n.push($o.redirectCount), n.push($o.size), n.push($o.type), n.push($o.protocol), n.push($o.encodedSize), n.push($o.decodedSize), tu(), ni(n)), [2]
                    }))
                }))
            }(29)
    }
    var nu, au = 0,
        ru = 1 / 0,
        iu = 0,
        ou = 0,
        uu = [],
        cu = new Map,
        su = function() {
            return au || 0
        },
        lu = function() {
            if (!uu.length) return -1;
            var t = Math.min(uu.length - 1, Math.floor((su() - ou) / 50));
            return uu[t].latency
        },
        du = function() {
            ou = su(), uu.length = 0, cu.clear()
        },
        fu = function(t) {
            if (t.interactionId && !(t.duration < 40)) {
                ! function(t) {
                    "interactionCount" in performance ? au = performance.interactionCount : t.interactionId && (ru = Math.min(ru, t.interactionId), iu = Math.max(iu, t.interactionId), au = iu ? (iu - ru) / 7 + 1 : 0)
                }(t);
                var e = uu[uu.length - 1],
                    n = cu.get(t.interactionId);
                if (n || uu.length < 10 || t.duration > (null == e ? void 0 : e.latency)) {
                    if (n) t.duration > n.latency && (n.latency = t.duration);
                    else {
                        var a = {
                            id: t.interactionId,
                            latency: t.duration
                        };
                        cu.set(a.id, a), uu.push(a)
                    }
                    uu.sort((function(t, e) {
                        return e.latency - t.latency
                    })), uu.length > 10 && uu.splice(10).forEach((function(t) {
                        return cu.delete(t.id)
                    }))
                }
            }
        },
        pu = ["navigation", "resource", "longtask", "first-input", "layout-shift", "largest-contentful-paint", "event"];

    function hu() {
        try {
            nu && nu.disconnect(), nu = new PerformanceObserver(Co(vu));
            for (var t = 0, e = pu; t < e.length; t++) {
                var n = e[t];
                PerformanceObserver.supportedEntryTypes.indexOf(n) >= 0 && ("layout-shift" === n && Q(9, 0), nu.observe({
                    type: n,
                    buffered: !0
                }))
            }
        } catch (t) {
            hi(3, 1)
        }
    }

    function vu(t) {
        ! function(t) {
            for (var e = (!("visibilityState" in document) || "visible" === document.visibilityState), n = 0; n < t.length; n++) {
                var a = t[n];
                switch (a.entryType) {
                    case "navigation":
                        eu(a);
                        break;
                    case "resource":
                        var r = a.name;
                        Gi(4, mu(r)), r !== u.upload && r !== u.fallback || $(28, a.duration);
                        break;
                    case "longtask":
                        Z(7);
                        break;
                    case "first-input":
                        e && $(10, a.processingStart - a.startTime);
                        break;
                    case "event":
                        e && "PerformanceEventTiming" in window && "interactionId" in PerformanceEventTiming.prototype && (fu(a), Gi(37, lu().toString()));
                        break;
                    case "layout-shift":
                        e && !a.hadRecentInput && Q(9, 1e3 * a.value);
                        break;
                    case "largest-contentful-paint":
                        e && $(8, a.startTime)
                }
            }
        }(t.getEntries())
    }
    var gu = null;

    function mu(t) {
        return gu || (gu = document.createElement("a")), gu.href = t, gu.host
    }
    var yu = [Zo, Qo, cn, Object.freeze({
        __proto__: null,
        start: function() {
            tu(),
                function() {
                    navigator && navigator.connection && Gi(27, navigator.connection.effectiveType), window.PerformanceObserver && PerformanceObserver.supportedEntryTypes ? "complete" !== document.readyState ? Po(window, "load", tt.bind(this, hu, 0)) : hu() : hi(3, 0)
                }()
        },
        stop: function() {
            nu && nu.disconnect(), nu = null, du(), gu = null, tu()
        }
    }), Gr];

    function bu(t) {
        void 0 === t && (t = null),
            function() {
                try {
                    var t = navigator && "globalPrivacyControl" in navigator && 1 == navigator.globalPrivacyControl;
                    return !1 === Vo && "undefined" != typeof Promise && window.MutationObserver && document.createTreeWalker && "now" in Date && "now" in performance && "undefined" != typeof WeakMap && !t
                } catch (t) {
                    return !1
                }
            }() && (! function(t) {
                if (null === t || Vo) return !1;
                for (var e in t) e in u && (u[e] = t[e])
            }(t), Bo(), Ut(), yu.forEach((function(t) {
                return Co(t.start)()
            })), null === t && Eu())
    }

    function wu() {
        Go() && (yu.slice().reverse().forEach((function(t) {
            return Co(t.stop)()
        })), Ft(), Jo(), void 0 !== ku && (ku[Ou] = function() {
            (ku[Ou].q = ku[Ou].q || []).push(arguments), "start" === arguments[0] && ku[Ou].q.unshift(ku[Ou].q.pop()) && Eu()
        }))
    }
    var Su = Object.freeze({
            __proto__: null,
            consent: co,
            consentv2: so,
            dlog: Gi,
            event: B,
            hashText: nr,
            identify: wt,
            maxMetric: $,
            measure: Co,
            metadata: oo,
            pause: function() {
                Go() && (B("clarity", "pause"), null === bi && (bi = new Promise((function(t) {
                    wi = t
                }))))
            },
            queue: ni,
            register: Hr,
            resume: function() {
                Go() && (bi && (wi(), bi = null, null === yi && Oi()), B("clarity", "resume"))
            },
            schedule: ki,
            set: bt,
            signal: function(t) {
                zt = t
            },
            start: bu,
            stop: wu,
            time: d,
            upgrade: Yi,
            version: f
        }),
        ku = window,
        Ou = "clarity";

    function Eu() {
        if (void 0 !== ku) {
            if (ku[Ou] && ku[Ou].v) return console.warn("Error CL001: Multiple Clarity tags detected.");
            var t = ku[Ou] && ku[Ou].q || [];
            for (ku[Ou] = function(t) {
                    for (var e = [], n = 1; n < arguments.length; n++) e[n - 1] = arguments[n];
                    return Su[t].apply(Su, e)
                }, ku[Ou].v = f; t.length > 0;) ku[Ou].apply(ku, t.shift())
        }
    }
    Eu()
}();